#include "dnn_vad.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
typedef HMODULE dl_handle;
#define DL_OPEN(p) LoadLibraryA(p)
#define DL_SYM(h, n) ((void *)GetProcAddress((h), (n)))
#define DL_CLOSE(h) FreeLibrary(h)
#define DL_ERR() "see GetLastError()"
#define DL_SUFFIX "tensorflowlite_c.dll"
#define DL_CORE NULL
#else
#include <dlfcn.h>
typedef void *dl_handle;
#define DL_OPEN(p) dlopen((p), RTLD_NOW | RTLD_GLOBAL)
#define DL_SYM(h, n) dlsym((h), (n))
#define DL_CLOSE(h) dlclose(h)
#define DL_ERR() dlerror()
#define DL_SUFFIX "libtensorflowlite_c.so"
/* THE CALLER MUST SET LD_LIBRARY_PATH to lib_dir.
 *
 * libtensorflowlite_c.so needs libtensorflow-lite.so, which in turn needs
 * libfarmhash, libcpuinfo, libpthreadpool, libfft2d_* and several libabsl_*.
 * None are on the default search path, and musl fixes that path at startup, so
 * setenv() from here is ignored.
 *
 * Preloading the directory with RTLD_GLOBAL was tried and does NOT work: musl
 * resolves DT_NEEDED by name against its loaded list, and these libraries carry
 * no SONAME, so a copy opened by full path is never matched. Verified on the
 * device - it failed identically with and without the preload. */
#define DL_CORE "libtensorflow-lite.so"
#endif

#define BINS 64
#define CHANS 6
#define STATE 42

typedef int (*fn_status)(void *);
typedef void *(*fn_ptr_ptr)(void *, int);
typedef int (*fn_copy)(void *, const void *, size_t);

struct dnn_vad {
    dl_handle core, lib;
    void *model, *interp;
    /* Newest-first ring of the last CHANS hops of magnitude. */
    float hist[CHANS][BINS];
    unsigned filled;
    float in[BINS * CHANS];
    float s1[STATE], s2[STATE];
    unsigned long hops, errors;

    void *(*model_create)(const char *);
    void (*model_delete)(void *);
    void *(*interp_create)(void *, void *);
    void (*interp_delete)(void *);
    fn_status alloc_tensors;
    fn_status invoke;
    fn_ptr_ptr input_tensor;
    fn_ptr_ptr output_tensor;
    fn_copy copy_from;
    int (*copy_to)(void *, void *, size_t);
};

static int path_join(char *out, size_t n, const char *dir, const char *leaf)
{
    if (!dir || !*dir)
        return snprintf(out, n, "%s", leaf) >= (int)n;
    return snprintf(out, n, "%s/%s", dir, leaf) >= (int)n;
}

dnn_vad *dnn_vad_create(const char *model_path, const char *lib_dir)
{
    char path[1024];
    dnn_vad *s;

    if (!model_path || !*model_path)
        return NULL;
    s = calloc(1, sizeof(*s));
    if (!s)
        return NULL;

#ifndef _WIN32
    if (DL_CORE) {
        if (path_join(path, sizeof(path), lib_dir, DL_CORE))
            goto fail;
        s->core = DL_OPEN(path);   /* best effort: may already be resolvable */
        if (!s->core) {
            const char *e = DL_ERR();
            fprintf(stderr, "dnn-vad: %s: %s\n", path, e ? e : "not preloaded");
        }
    }
#endif
    if (path_join(path, sizeof(path), lib_dir, DL_SUFFIX))
        goto fail;
    s->lib = DL_OPEN(path);
    if (!s->lib) {
        const char *e = DL_ERR();
        fprintf(stderr, "dnn-vad: %s: %s\n", path, e ? e : "cannot load");
        goto fail;
    }

    s->model_create = (void *(*)(const char *))DL_SYM(s->lib, "TfLiteModelCreateFromFile");
    s->model_delete = (void (*)(void *))DL_SYM(s->lib, "TfLiteModelDelete");
    s->interp_create = (void *(*)(void *, void *))DL_SYM(s->lib, "TfLiteInterpreterCreate");
    s->interp_delete = (void (*)(void *))DL_SYM(s->lib, "TfLiteInterpreterDelete");
    s->alloc_tensors = (fn_status)DL_SYM(s->lib, "TfLiteInterpreterAllocateTensors");
    s->invoke = (fn_status)DL_SYM(s->lib, "TfLiteInterpreterInvoke");
    s->input_tensor = (fn_ptr_ptr)DL_SYM(s->lib, "TfLiteInterpreterGetInputTensor");
    s->output_tensor = (fn_ptr_ptr)DL_SYM(s->lib, "TfLiteInterpreterGetOutputTensor");
    s->copy_from = (fn_copy)DL_SYM(s->lib, "TfLiteTensorCopyFromBuffer");
    s->copy_to = (int (*)(void *, void *, size_t))DL_SYM(s->lib, "TfLiteTensorCopyToBuffer");
    if (!s->model_create || !s->model_delete || !s->interp_create ||
        !s->interp_delete || !s->alloc_tensors || !s->invoke ||
        !s->input_tensor || !s->output_tensor || !s->copy_from || !s->copy_to)
        goto fail;

    s->model = s->model_create(model_path);
    if (!s->model) {
        fprintf(stderr, "dnn-vad: %s: model rejected by TfLiteModelCreateFromFile\n",
                model_path);
        goto fail;
    }
    s->interp = s->interp_create(s->model, NULL);
    if (!s->interp)
        goto fail;
    if (s->alloc_tensors(s->interp) != 0)
        goto fail;

    dnn_vad_reset(s);
    return s;

fail:
    dnn_vad_destroy(s);
    return NULL;
}

void dnn_vad_destroy(dnn_vad *s)
{
    if (!s)
        return;
    if (s->interp && s->interp_delete)
        s->interp_delete(s->interp);
    if (s->model && s->model_delete)
        s->model_delete(s->model);
    if (s->lib)
        DL_CLOSE(s->lib);
    /* s->core is deliberately left loaded: other users may hold symbols. */
    free(s);
}

void dnn_vad_reset(dnn_vad *s)
{
    if (!s)
        return;
    memset(s->hist, 0, sizeof(s->hist));
    memset(s->s1, 0, sizeof(s->s1));
    memset(s->s2, 0, sizeof(s->s2));
    s->filled = 0;
}

float dnn_vad_process(dnn_vad *s, const float *mag64)
{
    void *t;
    float prob = 0.f;
    unsigned c, b;

    if (!s || !mag64)
        return -1.f;

    /* Shift the ring so index 0 is the newest frame, matching the layout the
     * model was characterised with. */
    for (c = CHANS - 1; c > 0; c--)
        memcpy(s->hist[c], s->hist[c - 1], sizeof(s->hist[0]));
    memcpy(s->hist[0], mag64, sizeof(s->hist[0]));
    if (s->filled < CHANS) {
        /* Before the ring is full, repeat the oldest real frame rather than
         * feed zeros, which the model reads as silence. */
        s->filled++;
        for (c = s->filled; c < CHANS; c++)
            memcpy(s->hist[c], s->hist[s->filled - 1], sizeof(s->hist[0]));
    }

    /* [1, 64, 1, 6] is bin-major with channel fastest. */
    for (b = 0; b < BINS; b++)
        for (c = 0; c < CHANS; c++)
            s->in[b * CHANS + c] = s->hist[c][b];

    s->hops++;
    t = s->input_tensor(s->interp, 0);
    if (!t || s->copy_from(t, s->s1, sizeof(s->s1)) != 0)
        goto err;
    t = s->input_tensor(s->interp, 1);
    if (!t || s->copy_from(t, s->s2, sizeof(s->s2)) != 0)
        goto err;
    t = s->input_tensor(s->interp, 2);
    if (!t || s->copy_from(t, s->in, sizeof(s->in)) != 0)
        goto err;
    if (s->invoke(s->interp) != 0)
        goto err;
    t = s->output_tensor(s->interp, 0);
    if (!t || s->copy_to(t, &prob, sizeof(prob)) != 0)
        goto err;
    t = s->output_tensor(s->interp, 1);
    if (!t || s->copy_to(t, s->s1, sizeof(s->s1)) != 0)
        goto err;
    t = s->output_tensor(s->interp, 2);
    if (!t || s->copy_to(t, s->s2, sizeof(s->s2)) != 0)
        goto err;

    if (!(prob >= 0.f))          /* also catches NaN */
        prob = 0.f;
    if (prob > 1.f)
        prob = 1.f;
    return prob;

err:
    s->errors++;
    return -1.f;
}

void dnn_vad_stats(const dnn_vad *s, unsigned long *hops, unsigned long *errors)
{
    if (hops)
        *hops = s ? s->hops : 0;
    if (errors)
        *errors = s ? s->errors : 0;
}
