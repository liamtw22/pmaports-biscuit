#ifndef FOS6_DNN_VAD_H
#define FOS6_DNN_VAD_H

/* Stock Fire OS 6's DNN voice activity detector, vad_lite.tflite.
 *
 * Runs on the libtensorflowlite_c we already ship for microWakeWord, loaded at
 * RUNTIME so this binary keeps working when the model is absent. The model is a
 * proprietary Amazon file living on system_a, which the merged v2 conversion
 * destroys, so it is owner-imported and is NEVER a build dependency. When it
 * cannot be loaded the caller falls back to the energy prototype.
 *
 * Input is 64 LINEAR magnitudes per hop - bins 0..63 of a 256-point analysis
 * with the 768-tap prototype, taken from the MERGED BEAM after synthesis.
 * Established by measurement:
 *
 *   - six consecutive frames of linear magnitude, newest first, at unit scale
 *   - fed the merged beam, not a microphone: on the playback capture the raw
 *     centre mic scores AUC 0.5175 (chance) and the merged beam 0.9098
 *   - every log-magnitude variant sits at chance; every scale above x1 is worse
 *
 * The six frames are stacked here, so the caller supplies one hop at a time.
 */

typedef struct dnn_vad dnn_vad;

/* model_path: the owner-imported vad_lite.tflite.
 * lib_dir:    directory holding libtensorflowlite_c.so and libtensorflow-lite.so
 *             (NULL uses the platform default search path).
 *             THE CALLER MUST ALSO PUT lib_dir ON LD_LIBRARY_PATH - the stack
 *             pulls in libfarmhash, libcpuinfo, libpthreadpool, libfft2d_* and
 *             several libabsl_*, none on the default path, and musl fixes that
 *             path at startup so setenv() here cannot help.
 * Returns NULL if either cannot be loaded; that is an expected outcome, not an
 * error, and the caller must fall back. */
dnn_vad *dnn_vad_create(const char *model_path, const char *lib_dir);
void dnn_vad_destroy(dnn_vad *s);

/* Clear the recurrent state and the frame history. Call on a stream
 * discontinuity, alongside aec_reset(). */
void dnn_vad_reset(dnn_vad *s);

/* One hop. mag64 is 64 linear magnitudes. Returns P(speech) in 0..1, or a
 * negative value if inference failed. */
float dnn_vad_process(dnn_vad *s, const float *mag64);

/* Diagnostics: total invocations and failures. */
void dnn_vad_stats(const dnn_vad *s, unsigned long *hops, unsigned long *errors);

#endif
