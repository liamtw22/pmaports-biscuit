#ifndef BISCUIT_GROUP_POLICY_H
#define BISCUIT_GROUP_POLICY_H
/* Numerical portion of the non-sliding/non-per-tone GroupBeamMergerV2 path.
 * Both vectors are explicit upstream metrics, not inferred from PCM here.
 * Requires finite numerator >=0 and denominator >0. Invalid/unrepresentable
 * metrics reject atomically. These guards are portable safety policy.
 * Selected group is supplied by the caller; no new selection policy implied.
 * Groups are [g,g+1,g+2] modulo 8. */
int stock_group_observe(const float numerator[8],const float denominator[8],
    unsigned selected_group,float group_metrics[8],float beam_weights[8]);
#endif
