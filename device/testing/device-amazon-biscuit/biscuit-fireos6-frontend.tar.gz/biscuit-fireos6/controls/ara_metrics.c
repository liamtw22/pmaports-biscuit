#include "ara_metrics.h"
#include <math.h>
#include <string.h>
void ara_metrics_init(ara_metrics_state *s){
    if(!s)return;
    memset(s,0,sizeof(*s));for(unsigned b=0;b<8;b++)s->denominator[b]=1;
}
static float band_power(const aec_complex *x,unsigned first,unsigned last){
    float re=0,im=0;
    for(unsigned k=first;k<=last;k++){
        float r=x[k].re*8388608.f,i=x[k].im*8388608.f;
        re+=r*r;im+=i*i;
    }
    return (re+im)*(1.f/(float)(last-first+1));
}
static void power_pair(float power,float *signal,float *slow){
    float alpha=power>*signal*1.2f?.75f:.987f;
    *signal=*signal*alpha+power*(1.f-alpha);
    *slow=*slow*.987f+power*(1.f-.987f);
}
static float history_min(float *history,unsigned cursor,float value){
    history[cursor]=value;
    float minimum=history[0];
    for(unsigned i=1;i<512;i++)if(history[i]<minimum)minimum=history[i];
    return minimum>1.f?minimum:1.f;
}
int ara_metrics_step(ara_metrics_state *s,const aec_complex *x,ara_metrics_report *out){
    if(!s||!x||!out)return -1;
    for(unsigned i=0;i<8*128;i++)if(!isfinite(x[i].re)||!isfinite(x[i].im)||
        fabsf(x[i].re)>1024||fabsf(x[i].im)>1024)return -1;
    for(unsigned b=0;b<8;b++){
        float narrow=band_power(x+b*128,6,40),wide=band_power(x+b*128,8,72);
        power_pair(narrow,&s->narrow_signal[b],&s->narrow_slow[b]);
        float nmin=history_min(s->narrow_history[b],s->cursor[b],s->narrow_slow[b]);
        s->narrow_snr[b]=s->narrow_snr[b]*.75f+(s->narrow_signal[b]/nmin)*.25f;
        power_pair(wide,&s->wide_signal[b],&s->wide_slow[b]);
        float wmin=history_min(s->wide_history[b],s->cursor[b],s->wide_slow[b]);
        s->wide_snr[b]=s->wide_snr[b]*.75f+(s->wide_signal[b]/(wmin+1e-6f))*.25f;
        s->denominator[b]=s->denominator[b]*.75f+wmin*.25f;
        s->cursor[b]=(s->cursor[b]+1)%512;
    }
    memcpy(out->narrow_snr,s->narrow_snr,sizeof(s->narrow_snr));
    memcpy(out->merger_numerator,s->wide_snr,sizeof(s->wide_snr));
    memcpy(out->merger_denominator,s->denominator,sizeof(s->denominator));
    return 0;
}
