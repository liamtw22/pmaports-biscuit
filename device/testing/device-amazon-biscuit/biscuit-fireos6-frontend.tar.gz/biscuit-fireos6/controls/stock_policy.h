#ifndef BISCUIT_STOCK_POLICY_H
#define BISCUIT_STOCK_POLICY_H
#include <stddef.h>
#include <stdint.h>

/* Bounded, allocation-free reconstruction of owner-local AECARAUtilsV2
 * primitives. The upstream stock tap and final controller wiring remain
 * unqualified: these outputs are observations, never implicit adapt masks. */
enum { STOCK_POLICY_HOP=128, STOCK_POLICY_MIN_HISTORY=128,
       STOCK_POLICY_BUCKETS=20, STOCK_POLICY_HOPS_PER_BUCKET=125 };
typedef struct {
    float reference_fast, reference_slow, microphone_fast, microphone_slow;
    float reference_factor, microphone_factor, minimum;
    float probability_first, probability_second;
    unsigned reference_active, reference_average_active;
    unsigned microphone_active, microphone_average_active;
    unsigned hops_in_bucket, completed_buckets, bucket_cursor, minimum_cursor;
    unsigned count[3];
    float history[3][STOCK_POLICY_BUCKETS], minimum_history[STOCK_POLICY_MIN_HISTORY];
} stock_policy_state;
typedef struct {
    float reference_fast, reference_slow, microphone_fast, microphone_slow;
    float reference_factor, microphone_factor, minimum;
    float probability_first, probability_second;
    unsigned reference_active, reference_average_active;
    unsigned microphone_active, microphone_average_active;
    unsigned hops_in_bucket, completed_buckets, probability_updated;
} stock_policy_report;

void stock_policy_init(stock_policy_state *s);
/* Stock reset preserves the probability pair. Use init for a new stream or
 * generation; preserving it across a route change would be unsafe policy. */
void stock_policy_reset_history(stock_policy_state *s);
/* Exactly one 8 ms hop of normalized mono PCM on both explicit inputs.
 * A null reference is rejected; missing reference must not become silence.
 * force_first is applied only on the once-per-second update, as in stock.
 * Invalid input returns -1 without changing state or report. */
int stock_policy_step(stock_policy_state *s, const float *microphone,
    const float *reference, size_t frames, int force_first,
    stock_policy_report *report);
/* Verified subroutines, separated for owner-local oracle and explicit
 * upstream integration. Powers must be finite and nonnegative. */
int stock_policy_levels(stock_policy_state *s,float microphone_mean_power,
    float reference_mean_power);
int stock_policy_probability(stock_policy_state *s,float microphone_slow_power,
    int force_first);
void stock_policy_read(const stock_policy_state *s,stock_policy_report *out);
#endif
