#include "stock_policy.h"
#include <math.h>
#include <string.h>

static float smooth(float old,float sample,float alpha){
    return alpha*old+(1.f-alpha)*sample;
}
void stock_policy_init(stock_policy_state *s){
    if(!s)return;
    memset(s,0,sizeof(*s));s->probability_second=1;
    s->reference_factor=s->microphone_factor=1;
}
void stock_policy_reset_history(stock_policy_state *s){
    if(!s)return;
    memset(s->history,0,sizeof(s->history));
    memset(s->minimum_history,0,sizeof(s->minimum_history));
    memset(s->count,0,sizeof(s->count));
    s->hops_in_bucket=s->completed_buckets=s->bucket_cursor=s->minimum_cursor=0;
    s->reference_fast=s->reference_slow=s->microphone_fast=s->microphone_slow=0;
    s->reference_factor=s->microphone_factor=1;
}
int stock_policy_levels(stock_policy_state *s,float mic,float ref){
    if(!s||!isfinite(mic)||!isfinite(ref)||mic<0||ref<0)return -1;
    s->reference_fast=smooth(s->reference_fast,ref,.987f);
    s->reference_slow=smooth(s->reference_slow,ref,.999f);
    s->microphone_fast=smooth(s->microphone_fast,mic,.999f);
    s->microphone_slow=smooth(s->microphone_slow,mic,.999f);
    s->reference_factor=fminf(1.f,s->reference_fast/5e-7f);
    s->microphone_factor=fminf(1.f,s->microphone_fast/1e-8f);
    s->reference_active=s->reference_average_active=s->reference_fast>=5e-7f;
    s->microphone_active=s->microphone_fast>=1e-8f;
    s->microphone_average_active=s->microphone_slow>=1e-8f;
    return 0;
}
int stock_policy_probability(stock_policy_state *s,float mic,int force){
    if(!s||!isfinite(mic)||mic<0||(force!=0&&force!=1))return -1;
    s->minimum_history[s->minimum_cursor]=mic;
    s->minimum_cursor=(s->minimum_cursor+1)%128;
    float minimum=s->minimum_history[0];
    for(unsigned i=1;i<128;i++)if(s->minimum_history[i]<minimum)minimum=s->minimum_history[i];
    s->minimum=minimum;
    unsigned bucket=minimum>=4.6e-5f?0:minimum>=1e-5f?1:2;
    s->count[bucket]++;
    if(++s->hops_in_bucket<125)return 0;
    s->hops_in_bucket=0;
    float sum[3]={0};
    for(unsigned k=0;k<3;k++){
        s->history[k][s->bucket_cursor]=(float)s->count[k];s->count[k]=0;
        for(unsigned i=0;i<20;i++)sum[k]+=s->history[k][i];
    }
    if(force){s->probability_first=1;s->probability_second=0;}
    else if(s->completed_buckets<20){s->probability_first=0;s->probability_second=1;}
    else if(sum[0]/2500.f>=.85f){s->probability_first=1;s->probability_second=0;}
    else if(sum[2]/2500.f>=.85f){s->probability_first=0;s->probability_second=1;}
    else {
        s->probability_first=(sum[0]+sum[1]*.70f)/2500.f;
        s->probability_second=1.f-s->probability_first;
    }
    s->bucket_cursor=(s->bucket_cursor+1)%20;
    if(s->completed_buckets<20)s->completed_buckets++;
    return 1;
}
void stock_policy_read(const stock_policy_state *s,stock_policy_report *r){
    if(!s||!r)return;
    memset(r,0,sizeof(*r));
    r->reference_fast=s->reference_fast;r->reference_slow=s->reference_slow;
    r->microphone_fast=s->microphone_fast;r->microphone_slow=s->microphone_slow;
    r->reference_factor=s->reference_factor;r->microphone_factor=s->microphone_factor;
    r->minimum=s->minimum;r->probability_first=s->probability_first;r->probability_second=s->probability_second;
    r->reference_active=s->reference_active;r->reference_average_active=s->reference_average_active;
    r->microphone_active=s->microphone_active;r->microphone_average_active=s->microphone_average_active;
    r->hops_in_bucket=s->hops_in_bucket;r->completed_buckets=s->completed_buckets;
}
int stock_policy_step(stock_policy_state *s,const float *mic,const float *ref,
    size_t frames,int force,stock_policy_report *r){
    if(!s||!mic||!ref||!r||frames!=128||(force!=0&&force!=1))return -1;
    for(unsigned i=0;i<128;i++)if(!isfinite(mic[i])||!isfinite(ref[i])||
        fabsf(mic[i])>16||fabsf(ref[i])>16)return -1;
    float mp=0,rp=0;
    for(unsigned i=0;i<128;i++){mp+=mic[i]*mic[i];rp+=ref[i]*ref[i];}
    stock_policy_levels(s,mp/128.f,rp/128.f);
    int updated=stock_policy_probability(s,s->microphone_slow,force);
    stock_policy_read(s,r);r->probability_updated=(unsigned)updated;
    return 0;
}
