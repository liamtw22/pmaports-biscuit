#include "group_policy.h"
#include <math.h>
#include <string.h>
int stock_group_observe(const float numerator[8],const float denominator[8],
    unsigned selected,float metrics[8],float weights[8]){
    if(!numerator||!denominator||!metrics||!weights||selected>=8)return -1;
    float maximum=1,score[8],group[8],weight[8]={0};
    for(unsigned b=0;b<8;b++){
        if(!isfinite(numerator[b])||!isfinite(denominator[b])||numerator[b]<0||denominator[b]<=0)return -1;
        if(denominator[b]>maximum)maximum=denominator[b];
    }
    for(unsigned b=0;b<8;b++){
        float ratio=maximum/denominator[b];
        score[b]=numerator[b]*ratio;
        if(!isfinite(ratio)||!isfinite(score[b]))return -1;
    }
    for(unsigned g=0;g<8;g++){
        group[g]=(score[g]+score[(g+1)%8])+score[(g+2)%8];
        if(!isfinite(group[g]))return -1;
    }
    for(unsigned i=0;i<3;i++){
        unsigned b=(selected+i)%8;
        weight[b]=group[selected]>1e-6f?score[b]/group[selected]:1.f/3.f;
    }
    memcpy(metrics,group,sizeof(group));memcpy(weights,weight,sizeof(weight));
    return 0;
}
