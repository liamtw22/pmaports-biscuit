#ifndef BISCUIT_ARA_METRICS_H
#define BISCUIT_ARA_METRICS_H
#include "../src/aec.h"
enum { ARA_METRICS_BEAMS=8, ARA_METRICS_BINS=128, ARA_METRICS_HISTORY=512 };
typedef struct {
    float narrow_signal[8],narrow_slow[8],wide_signal[8],wide_slow[8];
    float narrow_snr[8],wide_snr[8],denominator[8];
    float narrow_history[8][512],wide_history[8][512];
    unsigned cursor[8];
} ara_metrics_state;
typedef struct {
    float narrow_snr[8],merger_numerator[8],merger_denominator[8];
} ara_metrics_report;
void ara_metrics_init(ara_metrics_state *s);
/* Explicit normalized ARA residual, BEFORE any update-error power limiting.
 * Reconstructs NS6574's non-per-tone metric route with initial-noise frames=0.
 * Validates all input before mutation. Pure observation, no adaptation gate.
 * Keeps stock raw-power units internally for exact threshold parity. */
int ara_metrics_step(ara_metrics_state *s,const aec_complex *residual,
    ara_metrics_report *out);
#endif
