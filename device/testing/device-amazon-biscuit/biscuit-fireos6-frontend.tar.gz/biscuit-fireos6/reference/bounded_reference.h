/* SPDX-License-Identifier: MIT */
#ifndef BISCUIT_BOUNDED_REFERENCE_H
#define BISCUIT_BOUNDED_REFERENCE_H
#include <stddef.h>
#include <stdint.h>
#define BR_HOP 128u
#define BR_HISTORY 512u
#define BR_RENDER_RING 131072u
#define BR_RENDER_MAX_PUSH 4096u
#define BR_CAPTURE_QUEUE 16u
#define BR_MAX_JOB_AGE_NS UINT64_C(500000000)
#define BR_SLICE_INTERVAL_NS UINT64_C(4000000)
#define BR_SLICE_BUDGET_NS UINT64_C(500000)
#define BR_SLICE_UNITS 512u
struct br_context;
struct br_consumer;
enum br_source { BR_NONE = 0, BR_HARDWARE = 1, BR_SOFTWARE = 2 };
struct br_decision {
    enum br_source source;
    int reset_adaptive; /* Reset this consumer's AEC/reference filter history. */
    int freeze_adaptation; /* Neither trustworthy reference is available. */
    double confidence;
    uint64_t capture_generation, render_generation, capture_first;
};
struct br_stats {
    uint64_t submitted, queue_drops, generation_gaps, jobs_started;
    uint64_t jobs_completed, jobs_cancelled, jobs_expired, snapshot_rejects;
    uint64_t slices, max_slice_units, results, render_pushes;
};

/* Control-thread calls: allocation and lock-free-atomic check happen here.
 * Keep context alive until producers, worker and ALL consumers have stopped. */
struct br_context *br_create(void);
void br_destroy(struct br_context *ctx);
struct br_consumer *br_consumer_create(struct br_context *ctx);
void br_consumer_destroy(struct br_consumer *consumer);
uint64_t br_now_ns(void);

/* Exactly one render producer. first is an absolute 48 kHz mono frame index.
 * Generation/index discontinuity invalidates previous render history. Blocks
 * are <=4096 frames; call only for frames actually accepted by playback.
 * No allocation, file access, waiting or acquisition search. */
void br_render_invalidate(struct br_context *); /* sole render producer */
int br_render_push(struct br_context *, uint64_t generation, uint64_t first,
                   const int16_t *mono_s16, unsigned frames, uint64_t now_ns);

/* Exactly one capture producer, before assistant/call fanout. One 128-sample
 * hardware-reference hop in normalized S24 units (sample24 / 8388608).
 * Generation and first preserve capture identity across queues. A gap, invalid
 * pilot or overflow invalidates outstanding acquisition without waiting.
 * Returns 0 on queue overflow/invalid arguments; microphone delivery continues. */
int br_capture_submit(struct br_context *, uint64_t generation, uint64_t first,
                      const float hardware_normalized[BR_HOP], int valid,
                      uint64_t now_ns);

/* Exactly one NORMAL-PRIORITY background owner. No caller-side sleep needed:
 * slices are rate-limited internally, and missed slices never catch up.
 * Snapshot copying and <=512 coarse-equivalent work units occur here only.
 * now_ns is monotonic; work item budget uses the real monotonic clock.
 * Return slice units consumed. Snapshot copy is bounded separately, not
 * included in the cooperative 0.5 ms search target. */
unsigned br_worker_step(struct br_context *, uint64_t now_ns);

/* One caller per consumer; create independent consumers for assistant/call.
 * All output is normalized float PCM. Software FIR S16 counts /32768;
 * hardware is copied byte-for-byte when finite and valid. No AEC state lives
 * here. A bounded +/-12 current-pilot verification and 193-tap FIR remain in
 * this hot path; the long acquisition search does not. */
enum br_source br_reference_process(struct br_consumer *, uint64_t generation,
    uint64_t first, const float hardware_normalized[BR_HOP], int valid,
    uint64_t now_ns, float out_normalized[BR_HOP], struct br_decision *decision);

/* Thread-safe atomic diagnostics, for control/telemetry callers. */
void br_get_stats(const struct br_context *, struct br_stats *out);

/* Linux-only optional control/worker API; bridge/thread source is separate.
 * Open maps existing ER v1 read-only; invoke poll from the SAME owner as
 * br_worker_step. The bridge becomes the context's sole render producer.
 * Requires the audited stock overlay writer's <=256-frame write contract. */
struct br_legacy_bridge;
struct br_legacy_bridge *br_legacy_open(struct br_context *, const char *path);
/* Positive: copied frames; 0: no new data; -1: invalid/stale, reopen later. */
int br_legacy_poll(struct br_legacy_bridge *, uint64_t now_ns);
void br_legacy_close(struct br_legacy_bridge *);
/* Optional bounded diagnostics. Only read observations after joining the thread.
 * Passing no observer preserves the regular path without telemetry clocks/copies. */
#define BR_OBSERVATION_CAPACITY 512u
struct br_worker_progress { uint64_t started_ns; unsigned cursor,count,verify,active; };
/* Worker owner only, or after it has stopped; never a concurrent reader. */
void br_worker_get_progress(const struct br_context *,struct br_worker_progress *);
struct br_worker_sample {
    uint64_t start_ns,work_ns,sleep_ns,job_age_ns;
    unsigned units,cursor,count,verify,active;
};
struct br_thread_observation {
    uint64_t starts,slice_units,start_gap_sum_ns,start_gap_min_ns,start_gap_max_ns;
    uint64_t work_max_ns,sleep_max_ns,overflows;
    unsigned count,sleep_error;
    struct br_worker_sample samples[BR_OBSERVATION_CAPACITY];
};
struct br_thread;
struct br_thread *br_thread_start_observed(struct br_context *,const char *legacy_path,
    struct br_thread_observation *);
struct br_thread *br_thread_start(struct br_context *, const char *legacy_path);
void br_thread_stop(struct br_thread *); /* control thread only: joins worker */
#endif
