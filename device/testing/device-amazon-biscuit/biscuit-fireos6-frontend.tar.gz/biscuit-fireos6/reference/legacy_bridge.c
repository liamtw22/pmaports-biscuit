/* SPDX-License-Identifier: MIT
 * Read-only bridge for the audited ER v1 writer (<=256 frames per push).
 * All I/O, mapping and mirror copying runs outside capture/render callbacks.
 */
#define _GNU_SOURCE
#include "bounded_reference.h"
#include "br_atomic.h"
#ifndef _WIN32
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdatomic.h>
#include <pthread.h>
#include <sched.h>
#include <time.h>
#include <errno.h>
#define ER_MAGIC 0x45524632u
#define LEGACY_WRITER_MAX 256u
#define LEGACY_WINDOW 65536u
/* Layout MUST stay identical to live-echo-reference-20260911 ER v1. */
struct legacy_shared {
    _Atomic uint32_t magic,version,size,rate;
    _Atomic uint64_t generation,written,updated;
    _Atomic int16_t pcm[BR_RENDER_RING];
};
struct br_legacy_bridge {
    struct br_context *ctx;
    const struct legacy_shared *shared;
    uint64_t generation,cursor;
    int initialized,invalidated;
    int16_t scratch[BR_RENDER_MAX_PUSH];
};
struct br_legacy_bridge *br_legacy_open(struct br_context *ctx,const char *path) {
    if(!ctx||!path)return NULL;
    int fd=open(path,O_RDONLY|O_CLOEXEC|O_NOFOLLOW|O_NONBLOCK);
    if(fd<0)return NULL;
    struct stat st;
    if(fstat(fd,&st)||!S_ISREG(st.st_mode)||st.st_uid!=geteuid()||
       st.st_size!=(off_t)sizeof(struct legacy_shared)){close(fd);return NULL;}
    const struct legacy_shared *s=mmap(NULL,sizeof(*s),PROT_READ,MAP_SHARED,fd,0);
    close(fd);if(s==MAP_FAILED)return NULL;
    struct br_legacy_bridge *b=calloc(1,sizeof(*b));
    if(!b){munmap((void *)s,sizeof(*s));return NULL;}
    b->ctx=ctx;b->shared=s;return b;
}
static int reject(struct br_legacy_bridge *b) {
    if(!b->invalidated)br_render_invalidate(b->ctx);
    b->invalidated=1;b->initialized=0;return -1;
}
int br_legacy_poll(struct br_legacy_bridge *b,uint64_t now) {
    if(!b)return 0;
    const struct legacy_shared *s=b->shared;
    if(atomic_load_explicit(&s->magic,memory_order_acquire)!=ER_MAGIC||
       atomic_load(&s->version)!=1||atomic_load(&s->size)!=sizeof(*s)||
       atomic_load(&s->rate)!=48000)return reject(b);
    uint64_t gen=atomic_load_explicit(&s->generation,memory_order_acquire);
    uint64_t end=atomic_load_explicit(&s->written,memory_order_acquire);
    uint64_t updated=atomic_load_explicit(&s->updated,memory_order_acquire);
    if(!updated||(now>updated&&now-updated>UINT64_C(250000000))||
       end>(UINT64_MAX>>16)-BR_RENDER_MAX_PUSH)return reject(b);
    uint64_t recent_first=end>LEGACY_WINDOW?end-LEGACY_WINDOW:0;
    if(!b->initialized||b->generation!=gen||b->cursor<recent_first||b->cursor>end) {
        br_render_invalidate(b->ctx);b->cursor=recent_first;b->generation=gen;b->initialized=1;
    }
    b->invalidated=0;
    unsigned count=end-b->cursor>BR_RENDER_MAX_PUSH?BR_RENDER_MAX_PUSH:(unsigned)(end-b->cursor);
    if(!count)return 0;
    for(unsigned i=0;i<count;i++)b->scratch[i]=atomic_load_explicit(&s->pcm[(b->cursor+i)&(BR_RENDER_RING-1u)],memory_order_relaxed);
    uint64_t finish=atomic_load_explicit(&s->written,memory_order_acquire);
    /* Include the known <=256 samples which may already be being overwritten
     * before the writer's next end publication. Oldest-ring reads are forbidden.
     * The existing generic ABI alone cannot prove an arbitrary writer's bound. */
    uint64_t safe_first=finish+LEGACY_WRITER_MAX>BR_RENDER_RING?
        finish+LEGACY_WRITER_MAX-BR_RENDER_RING:0;
    if(atomic_load_explicit(&s->magic,memory_order_acquire)!=ER_MAGIC||
       atomic_load_explicit(&s->generation,memory_order_acquire)!=gen||
       finish<end||b->cursor<safe_first)return reject(b);
    if(!br_render_push(b->ctx,gen,b->cursor,b->scratch,count,updated))return reject(b);
    b->cursor+=count;return (int)count;
}
void br_legacy_close(struct br_legacy_bridge *b) {
    if(!b)return;
    br_render_invalidate(b->ctx);munmap((void *)b->shared,sizeof(*b->shared));free(b);
}
struct br_thread {
    struct br_context *ctx;
    pthread_t handle;
    br_atomic_u64 stop;
    char *legacy_path;
    struct br_thread_observation *observation;
};
static void *worker_main(void *arg) {
    struct br_thread *t=arg;struct br_legacy_bridge *bridge=NULL;uint64_t retry=0,previous_start=0;
    while(!br_load64(&t->stop)) {
        uint64_t now=br_now_ns();
        if(t->legacy_path&&!bridge&&now>=retry) {
            bridge=br_legacy_open(t->ctx,t->legacy_path);retry=now+UINT64_C(1000000000);
        }
        if(bridge&&br_legacy_poll(bridge,now)<0) {
            br_legacy_close(bridge);bridge=NULL;retry=now+UINT64_C(1000000000);
        }
        /* Enforce >=4 ms between actual step starts. A late start defines its
         * own new deadline, so no catch-up burst or extra work budget is added. */
        uint64_t started=br_now_ns(),deadline=started+BR_SLICE_INTERVAL_NS;
        unsigned units=br_worker_step(t->ctx,started);
        struct br_thread_observation *o=t->observation;
        struct br_worker_sample *sample=NULL;
        uint64_t work_end=o?br_now_ns():0;
        if(o) {
            o->starts++;o->slice_units+=units;
            if(previous_start) {
                uint64_t gap=started-previous_start;o->start_gap_sum_ns+=gap;
                if(!o->start_gap_min_ns||gap<o->start_gap_min_ns)o->start_gap_min_ns=gap;
                if(gap>o->start_gap_max_ns)o->start_gap_max_ns=gap;
            }
            if(work_end-started>o->work_max_ns)o->work_max_ns=work_end-started;
            if(o->count<BR_OBSERVATION_CAPACITY) {
                sample=&o->samples[o->count++];struct br_worker_progress progress;
                br_worker_get_progress(t->ctx,&progress);
                sample->start_ns=started;sample->work_ns=work_end-started;sample->units=units;
                sample->cursor=progress.cursor;sample->count=progress.count;
                sample->verify=progress.verify;sample->active=progress.active;
                sample->job_age_ns=progress.started_ns&&work_end>=progress.started_ns?work_end-progress.started_ns:0;
            } else o->overflows++;
        }
        previous_start=started;
        uint64_t sleep_start=o?br_now_ns():0;int sleep_error=0;
        while(!br_load64(&t->stop)) {
            uint64_t at=br_now_ns();if(at>=deadline)break;
            uint64_t left=deadline-at;
            struct timespec nap={(time_t)(left/UINT64_C(1000000000)),(long)(left%UINT64_C(1000000000))};
            if(!nanosleep(&nap,NULL))break;
            if(errno!=EINTR){sleep_error=errno;break;}
        }
        if(o) {
            uint64_t elapsed=br_now_ns()-sleep_start;
            if(elapsed>o->sleep_max_ns)o->sleep_max_ns=elapsed;
            if(sample)sample->sleep_ns=elapsed;
            if(sleep_error)o->sleep_error=(unsigned)sleep_error;
        }
        if(sleep_error)break; /* fail closed to hardware, never spin on errors */
    }
    br_legacy_close(bridge);return NULL;
}
struct br_thread *br_thread_start_observed(struct br_context *ctx,const char *path,
    struct br_thread_observation *observation) {
    if(!ctx)return NULL;
    struct br_thread *t=calloc(1,sizeof(*t));if(!t)return NULL;
    t->ctx=ctx;t->observation=observation;if(observation)memset(observation,0,sizeof(*observation));
    if(path&&!(t->legacy_path=strdup(path))){free(t);return NULL;}
    pthread_attr_t attr;
    if(pthread_attr_init(&attr)){free(t->legacy_path);free(t);return NULL;}
    struct sched_param param={.sched_priority=0};
    /* Never inherit a FIFO/RR audio caller's policy. Failure is visible. */
    int failed=pthread_attr_setinheritsched(&attr,PTHREAD_EXPLICIT_SCHED)||
        pthread_attr_setschedpolicy(&attr,SCHED_OTHER)||pthread_attr_setschedparam(&attr,&param);
    if(!failed)failed=pthread_create(&t->handle,&attr,worker_main,t);
    pthread_attr_destroy(&attr);
    if(failed){free(t->legacy_path);free(t);return NULL;}
    return t;
}
struct br_thread *br_thread_start(struct br_context *ctx,const char *path) {
    return br_thread_start_observed(ctx,path,NULL);
}
void br_thread_stop(struct br_thread *t) {
    if(!t)return;
    br_store64(&t->stop,1);pthread_join(t->handle,NULL);free(t->legacy_path);free(t);
}
#else
/* Windows host builds validate replay only. A requested live thread fails
 * explicitly instead of silently pretending a Unix shm bridge exists. */
struct br_legacy_bridge *br_legacy_open(struct br_context *ctx,const char *path) {
    (void)ctx;(void)path;return NULL;
}
int br_legacy_poll(struct br_legacy_bridge *b,uint64_t now) {
    (void)b;(void)now;return -1;
}
void br_legacy_close(struct br_legacy_bridge *b) { (void)b; }
struct br_thread *br_thread_start_observed(struct br_context *ctx,const char *path,
    struct br_thread_observation *observation) {
    (void)ctx;(void)path;(void)observation;return NULL;
}
struct br_thread *br_thread_start(struct br_context *ctx,const char *path) {
    return br_thread_start_observed(ctx,path,NULL);
}
void br_thread_stop(struct br_thread *t) { (void)t; }
#endif
