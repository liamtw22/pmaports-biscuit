/* SPDX-License-Identifier: MIT */
#ifndef BISCUIT_REFERENCE_PUBLICATION_H
#define BISCUIT_REFERENCE_PUBLICATION_H
#include "bounded_reference.h"
#define BR_PUBLICATION_SLOTS 64u
#define BR_PUBLICATION_MAX_AGE_NS UINT64_C(64000000)
struct br_publication_writer;
struct br_publication_reader;
/* Control-thread setup, Linux only. One same-UID writer holds an exclusive
 * nonblocking flock for its lifetime. Exact ABI and lock-free atomics required.
 * New files are private, and existing unrelated files are rejected. */
struct br_publication_writer *br_publication_writer_open(const char *path);
struct br_publication_reader *br_publication_reader_open(const char *path);
void br_publication_writer_close(struct br_publication_writer *);
void br_publication_reader_close(struct br_publication_reader *);

/* Single capture/reference owner publishes BEFORE fanout to assistant/call.
 * PCM is the already-selected normalized 128-sample reference; no microphones
 * or adaptive coefficients are shared. Steady-state work is fixed atomic stores,
 * no system call, allocation, queue wait or acquisition search.
 * Preserve the original capture receipt time, not a synthetic fresh timestamp. */
int br_publication_write(struct br_publication_writer *,const float pcm[BR_HOP],
    const struct br_decision *,uint64_t captured_ns,uint64_t published_ns);

/* Each process/branch owns a separate reader. Accept only the EXACT capture
 * identity and sample index, <=64ms capture age, matching publisher epoch and
 * consistent atomic slot. Missing/overwritten/stale output never causes a wait.
 * The branch's valid hardware reference is the fallback; invalid hardware
 * returns zero/freeze. Reset decisions are independent for each reader/AEC. */
enum br_source br_publication_read(struct br_publication_reader *,
    uint64_t capture_generation,uint64_t first,const float hardware[BR_HOP],
    int hardware_valid,uint64_t now_ns,float output[BR_HOP],struct br_decision *);
#endif
