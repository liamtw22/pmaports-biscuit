/* SPDX-License-Identifier: MIT */
#define _POSIX_C_SOURCE 200809L
#include "bounded_reference.h"
#include "br_atomic.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <limits.h>
#define BR_CANDIDATES 48001u
#define BR_SNAPSHOT (BR_CANDIDATES + 3u*(BR_HISTORY-1u))
#define BR_RADIUS 96
#define BR_TAPS (2*BR_RADIUS+1)
#define BR_RENDER_AGE_NS UINT64_C(250000000)
#define BR_RETRY_NS UINT64_C(250000000)
#define BR_MAX_INDEX (UINT64_MAX>>16)

struct capture_hop {
    uint64_t generation, epoch, first, at;
    int valid;
    float pcm[BR_HOP];
};
struct render_view { uint64_t sequence, generation, first, end, updated; };
struct seed {
    uint64_t capture_generation, epoch, capture_first;
    uint64_t render_generation, render_sequence, render_first, started, completed;
    double confidence;
};
struct acquisition {
    struct seed seed;
    float pilot[BR_HISTORY]; /* S16-count float domain, matching legacy score */
    int16_t pcm[BR_SNAPSHOT];
    unsigned count, cursor, top_count, verify, position;
    unsigned top_position[8];
    double top_score[8], confidence;
    double pilot_sum[3],pilot_variance[3];
    unsigned pilot_count[3];
    int active;
};
struct atomic_stats {
    br_atomic_u64 submitted, queue_drops, generation_gaps, jobs_started;
    br_atomic_u64 jobs_completed, jobs_cancelled, jobs_expired, snapshot_rejects;
    br_atomic_u64 slices, max_slice_units, results, render_pushes;
};
struct br_context {
    /* Capture slots are owned by the producer until head release, then worker
     * until tail release. Payloads are NOT read while another owner writes. */
    br_atomic_u64 head, tail, cap_epoch, cap_generation, requests;
    struct capture_hop capture[BR_CAPTURE_QUEUE];
    uint64_t producer_generation, producer_next, producer_epoch;
    int producer_seen;
    /* One render producer; atomic payload + seq validation, no reader waits. */
    br_atomic_u64 render_sequence, render_generation, render_first, render_end;
    br_atomic_u64 render_updated;
    /* 48-bit absolute-index tags reject in-flight overwrite before end publishes. */
    br_atomic_u64 rendered[BR_RENDER_RING];
    /* Small result publication. Every field is atomic, including double bits. */
    br_atomic_u64 result_sequence, result_fields[10];
    /* Worker-owned state and preallocated immutable active snapshot. */
    uint64_t worker_generation, worker_epoch, worker_next, pilot_at;
    uint64_t next_slice, serviced_request;
    float pilot[BR_HISTORY];
    unsigned fill;
    struct acquisition job;
    struct atomic_stats stats;
};
struct br_consumer {
    struct br_context *ctx;
    uint64_t generation, next, render_generation, render_sequence, epoch, position, request_at;
    unsigned fill;
    int seen, locked;
    enum br_source source;
    float hardware[BR_HISTORY], fir[BR_TAPS];
    double confidence;
};

uint64_t br_now_ns(void) {
#ifdef _WIN32
    LARGE_INTEGER t,f; QueryPerformanceCounter(&t); QueryPerformanceFrequency(&f);
    uint64_t n=(uint64_t)t.QuadPart,hz=(uint64_t)f.QuadPart;
    return n/hz*UINT64_C(1000000000)+(n%hz)*UINT64_C(1000000000)/hz;
#else
    struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t);
    return (uint64_t)t.tv_sec*UINT64_C(1000000000)+(uint64_t)t.tv_nsec;
#endif
}
static int fresh(uint64_t now,uint64_t then,uint64_t age) {
    return then && (then>now || now-then<=age);
}
static int finite_hop(const float *p) {
    if(!p)return 0;
    for(unsigned i=0;i<BR_HOP;i++)if(!isfinite(p[i])||fabsf(p[i])>1.f)return 0;
    return 1;
}
static int render_view(const struct br_context *c,struct render_view *v) {
    v->sequence=br_load64(&c->render_sequence);
    if(!v->sequence||(v->sequence&1))return 0;
    v->generation=br_load64(&c->render_generation);
    v->first=br_load64(&c->render_first);
    v->end=br_load64(&c->render_end);
    v->updated=br_load64(&c->render_updated);
    return v->sequence==br_load64(&c->render_sequence)&&v->first<=v->end;
}
static float render_sample(const struct br_context *c,uint64_t i,int *valid) {
    uint64_t packed=br_load64(&c->rendered[i&(BR_RENDER_RING-1u)]);
    if((packed>>16)!=i)*valid=0;
    uint16_t bits=(uint16_t)packed;
    int16_t signed_value; memcpy(&signed_value,&bits,sizeof(signed_value));
    return (float)signed_value;
}
static int render_unchanged(const struct br_context *c,const struct render_view *v) {
    return v->sequence==br_load64(&c->render_sequence);
}
static void publish_result(struct br_context *c,const struct seed *s) {
    uint64_t values[10]={s->capture_generation,s->epoch,s->capture_first,
        s->render_generation,s->render_first,s->started,s->completed,0,1,s->render_sequence};
    memcpy(&values[7],&s->confidence,sizeof(double));
    br_add64(&c->result_sequence,1);
    for(unsigned i=0;i<10;i++)br_store64(&c->result_fields[i],values[i]);
    br_add64(&c->result_sequence,1);
    br_add64(&c->stats.results,1);
}
static int get_result(const struct br_context *c,struct seed *s) {
    uint64_t sequence=br_load64(&c->result_sequence),v[10];
    if(!sequence||(sequence&1))return 0;
    for(unsigned i=0;i<10;i++)v[i]=br_load64(&c->result_fields[i]);
    if(sequence!=br_load64(&c->result_sequence)||!v[8])return 0;
    s->capture_generation=v[0];s->epoch=v[1];s->capture_first=v[2];
    s->render_generation=v[3];s->render_first=v[4];s->started=v[5];
    s->completed=v[6];s->render_sequence=v[9];memcpy(&s->confidence,&v[7],sizeof(double));
    return 1;
}
struct br_context *br_create(void) {
    if(!br_atomic_lock_free()||sizeof(double)!=sizeof(uint64_t))return NULL;
    struct br_context *c=calloc(1,sizeof(*c));
    if(c)br_store64(&c->requests,1);
    return c;
}
void br_destroy(struct br_context *c) { free(c); }
struct br_consumer *br_consumer_create(struct br_context *c) {
    if(!c)return NULL;
    struct br_consumer *r=calloc(1,sizeof(*r));
    if(!r)return NULL;
    r->ctx=c;double sum=0,pi=3.14159265358979323846;
    for(int i=0;i<BR_TAPS;i++) {
        int k=i-BR_RADIUS;double fc=7000./48000.;
        double value=k?sin(2*pi*fc*k)/(pi*k):2*fc;
        value*=.42-.5*cos(2*pi*i/(BR_TAPS-1))+.08*cos(4*pi*i/(BR_TAPS-1));
        r->fir[i]=(float)value;sum+=value;
    }
    for(int i=0;i<BR_TAPS;i++)r->fir[i]=(float)(r->fir[i]/sum);
    return r;
}
void br_consumer_destroy(struct br_consumer *r) { free(r); }
void br_render_invalidate(struct br_context *c) {
    if(!c)return;
    br_add64(&c->render_sequence,1);
    br_store64(&c->render_first,br_load64(&c->render_end));
    br_store64(&c->render_updated,0);
    br_add64(&c->render_sequence,1);br_add64(&c->requests,1);
}
int br_render_push(struct br_context *c,uint64_t generation,uint64_t first,
                   const int16_t *pcm,unsigned frames,uint64_t now) {
    if(!c||!pcm||!frames||frames>BR_RENDER_MAX_PUSH||first>BR_MAX_INDEX-frames)return 0;
    uint64_t old_end=br_load64(&c->render_end),old_first=br_load64(&c->render_first);
    int reset=generation!=br_load64(&c->render_generation)||first!=old_end||
              !br_load64(&c->render_sequence);
    if(reset){br_add64(&c->render_sequence,1);old_first=first;}
    for(unsigned i=0;i<frames;i++) {
        uint16_t bits;memcpy(&bits,&pcm[i],sizeof(bits));
        br_store64(&c->rendered[(first+i)&(BR_RENDER_RING-1u)],((first+i)<<16)|bits);
    }
    uint64_t end=first+frames;
    if(end-old_first>BR_RENDER_RING)old_first=end-BR_RENDER_RING;
    br_store64(&c->render_generation,generation);br_store64(&c->render_first,old_first);
    br_store64(&c->render_end,end);br_store64(&c->render_updated,now);
    if(reset)br_add64(&c->render_sequence,1);
    br_add64(&c->stats.render_pushes,1);
    if(reset)br_add64(&c->requests,1);
    return 1;
}
int br_capture_submit(struct br_context *c,uint64_t generation,uint64_t first,
                      const float hardware[BR_HOP],int valid,uint64_t now) {
    if(!c||first>BR_MAX_INDEX-BR_HOP)return 0;
    valid=valid&&finite_hop(hardware);
    int gap=!c->producer_seen||generation!=c->producer_generation||
            first!=c->producer_next||!valid;
    if(gap) {
        c->producer_epoch++;
        br_add64(&c->stats.generation_gaps,1);br_add64(&c->requests,1);
    }
    c->producer_seen=1;c->producer_generation=generation;c->producer_next=first+BR_HOP;
    br_store64(&c->cap_generation,generation);br_store64(&c->cap_epoch,c->producer_epoch);
    uint64_t head=br_load64(&c->head),tail=br_load64(&c->tail);
    if(head-tail>=BR_CAPTURE_QUEUE) {
        c->producer_epoch++;
        br_store64(&c->cap_epoch,c->producer_epoch);
        br_add64(&c->stats.queue_drops,1);br_add64(&c->requests,1);
        return 0;
    }
    struct capture_hop *h=&c->capture[head&(BR_CAPTURE_QUEUE-1u)];
    h->generation=generation;h->epoch=c->producer_epoch;h->first=first;h->at=now;h->valid=valid;
    if(valid)memcpy(h->pcm,hardware,sizeof(h->pcm));else memset(h->pcm,0,sizeof(h->pcm));
    br_store64(&c->head,head+1);br_add64(&c->stats.submitted,1);
    return 1;
}
/* The immutable pilot's sums do not depend on candidate position. Cache them
 * with the ORIGINAL accumulation order; the per-candidate formula is unchanged.
 * This removes two repeated accumulators per pair, not a timing/quality bound. */
static void cache_pilot_statistics(struct acquisition *j) {
    const unsigned steps[3]={16,1,1},starts[3]={0,0,BR_HISTORY-BR_HOP};
    for(unsigned kind=0;kind<3;kind++) {
        double sum=0,power=0;unsigned n=0;
        for(unsigned i=starts[kind];i<BR_HISTORY;i+=steps[kind]) {
            double x=j->pilot[i];sum+=x;power+=x*x;n++;
        }
        j->pilot_sum[kind]=sum;j->pilot_variance[kind]=power-sum*sum/n;j->pilot_count[kind]=n;
    }
}
static double score_snapshot(const struct acquisition *j,unsigned p,unsigned step,unsigned from) {
    double xy=0,yy=0,ys=0;
    unsigned kind=from?2:(step==16?0:1),n=j->pilot_count[kind];
    for(unsigned i=from;i<BR_HISTORY;i+=step) {
        double x=j->pilot[i],y=j->pcm[p+3*i];
        xy+=x*y;yy+=y*y;ys+=y;
    }
    xy-=j->pilot_sum[kind]*ys/n;yy-=ys*ys/n;
    return fmin(1.,xy*xy/fmax(1.,j->pilot_variance[kind]*yy));
}
static unsigned acquisition_slice(struct acquisition *j) {
    unsigned used=0;uint64_t start=br_now_ns();
    while(used<BR_SLICE_UNITS&&br_now_ns()-start<BR_SLICE_BUDGET_NS) {
        if(j->cursor<j->count) {
            unsigned p=j->cursor++;double q=score_snapshot(j,p,16,0);used++;
            if(j->top_count<8||q>j->top_score[7]) {
                unsigned k=j->top_count<8?j->top_count++:7;
                while(k&&q>j->top_score[k-1]) {
                    j->top_score[k]=j->top_score[k-1];j->top_position[k]=j->top_position[k-1];k--;
                }
                j->top_score[k]=q;j->top_position[k]=p;
            }
        } else if(j->verify<j->top_count) {
            if(BR_SLICE_UNITS-used<20)break;
            unsigned p=j->top_position[j->verify++];
            double q=fmin(score_snapshot(j,p,1,0),score_snapshot(j,p,1,BR_HISTORY-BR_HOP));used+=20;
            if(q>j->confidence*j->confidence){j->confidence=sqrt(q);j->position=p;}
        } else break;
    }
    return used;
}
static void drain_capture(struct br_context *c) {
    /* Bounded, even while producer runs. Never drain an unbounded moving head. */
    uint64_t tail=br_load64(&c->tail),head=br_load64(&c->head);
    for(unsigned n=0;tail<head&&n<BR_CAPTURE_QUEUE;n++,tail++) {
        const struct capture_hop *h=&c->capture[tail&(BR_CAPTURE_QUEUE-1u)];
        if(h->generation!=c->worker_generation||h->epoch!=c->worker_epoch||
           h->first!=c->worker_next||!h->valid)c->fill=0;
        c->worker_generation=h->generation;c->worker_epoch=h->epoch;
        c->worker_next=h->first+BR_HOP;c->pilot_at=h->at;
        if(h->valid) {
            memmove(c->pilot,c->pilot+BR_HOP,(BR_HISTORY-BR_HOP)*sizeof(float));
            for(unsigned i=0;i<BR_HOP;i++)c->pilot[BR_HISTORY-BR_HOP+i]=h->pcm[i]*32768.f;
            if(c->fill<BR_HISTORY)c->fill+=BR_HOP;
        }
        br_store64(&c->tail,tail+1);
    }
}
static int begin_job(struct br_context *c,uint64_t now,const struct render_view *v) {
    if(c->fill<BR_HISTORY||c->worker_next<BR_HISTORY||
       c->worker_epoch!=br_load64(&c->cap_epoch)||
       c->worker_generation!=br_load64(&c->cap_generation)||
       !fresh(now,c->pilot_at,BR_MAX_JOB_AGE_NS)||!fresh(now,v->updated,BR_RENDER_AGE_NS))return 0;
    double energy=0;
    for(unsigned i=BR_HISTORY-BR_HOP;i<BR_HISTORY;i++)energy+=(double)c->pilot[i]*c->pilot[i];
    if(energy<BR_HOP*4.)return 0; /* no acquisition from silence */
    uint64_t lo=v->first+BR_RADIUS;
    const unsigned required=3*(BR_HISTORY-1)+BR_RADIUS+1;
    if(v->end<required)return 0;
    uint64_t hi=v->end-required;
    if(hi<lo)return 0;
    if(hi-lo>BR_CANDIDATES-1)lo=hi-(BR_CANDIDATES-1);
    unsigned samples=(unsigned)(hi-lo+1)+3*(BR_HISTORY-1);
    struct acquisition *j=&c->job;
    memset(j,0,sizeof(*j));
    memcpy(j->pilot,c->pilot,sizeof(j->pilot));
    cache_pilot_statistics(j);
    int consistent=1;
    for(unsigned i=0;i<samples;i++)j->pcm[i]=(int16_t)render_sample(c,lo+i,&consistent);
    if(!consistent||!render_unchanged(c,v)) {br_add64(&c->stats.snapshot_rejects,1);return 0;}
    j->count=(unsigned)(hi-lo+1);
    j->seed.capture_generation=c->worker_generation;j->seed.epoch=c->worker_epoch;
    j->seed.capture_first=c->worker_next-BR_HISTORY;
    j->seed.render_generation=v->generation;j->seed.render_sequence=v->sequence;j->seed.render_first=lo;
    /* Pilot age, not delayed worker start, bounds the result's lifetime. */
    j->seed.started=c->pilot_at;j->active=1;
    c->serviced_request=br_load64(&c->requests);
    br_add64(&c->stats.jobs_started,1);
    return 1;
}
unsigned br_worker_step(struct br_context *c,uint64_t now) {
    if(!c||now<c->next_slice)return 0;
    c->next_slice=now+BR_SLICE_INTERVAL_NS;
    drain_capture(c);
    struct render_view v;int have_render=render_view(c,&v);
    struct acquisition *j=&c->job;
    if(j->active) {
        int changed=j->seed.epoch!=br_load64(&c->cap_epoch)||
            j->seed.capture_generation!=br_load64(&c->cap_generation)||
            j->seed.render_generation!=br_load64(&c->render_generation)||
            j->seed.render_sequence!=br_load64(&c->render_sequence);
        int expired=now<j->seed.started||now-j->seed.started>BR_MAX_JOB_AGE_NS;
        if(changed||expired) {
            j->active=0;
            br_add64(changed?&c->stats.jobs_cancelled:&c->stats.jobs_expired,1);
            /* A cancelled generation may have consumed the only request. */
            c->serviced_request=0;
        }
    }
    if(!j->active&&have_render&&c->serviced_request!=br_load64(&c->requests))begin_job(c,now,&v);
    if(!j->active)return 0;
    unsigned used=acquisition_slice(j);br_add64(&c->stats.slices,1);
    if(used>br_load64(&c->stats.max_slice_units))br_store64(&c->stats.max_slice_units,used);
    if(j->cursor==j->count&&j->verify==j->top_count) {
        j->active=0;br_add64(&c->stats.jobs_completed,1);
        /* Recheck after work: reset/overrun cannot publish a stale seed. */
        struct render_view finish;
        if(j->confidence>=.65&&render_view(c,&finish)&&
           finish.generation==j->seed.render_generation&&finish.sequence==j->seed.render_sequence&&
           j->seed.epoch==br_load64(&c->cap_epoch)&&
           j->seed.capture_generation==br_load64(&c->cap_generation)&&
           now>=j->seed.started&&now-j->seed.started<=BR_MAX_JOB_AGE_NS) {
            uint64_t matched=j->seed.render_first+j->position;
            if(matched>=finish.first+BR_RADIUS&&
               matched+3*(BR_HISTORY-1)+BR_RADIUS<finish.end) {
                j->seed.render_first=matched;j->seed.completed=now;
                j->seed.confidence=j->confidence;publish_result(c,&j->seed);
            }
        }
    }
    return used;
}
void br_worker_get_progress(const struct br_context *c,struct br_worker_progress *out) {
    if(!c||!out)return;
    out->started_ns=c->job.seed.started;out->cursor=c->job.cursor;out->count=c->job.count;
    out->verify=c->job.verify;out->active=(unsigned)c->job.active;
}
static double score_current(const struct br_consumer *r,uint64_t p,int *consistent) {
    double xy=0,xx=0,yy=0,xs=0,ys=0;
    for(unsigned i=BR_HISTORY-BR_HOP;i<BR_HISTORY;i++) {
        double x=r->hardware[i],y=render_sample(r->ctx,p+3*i,consistent);
        xy+=x*y;xx+=x*x;yy+=y*y;xs+=x;ys+=y;
    }
    xy-=xs*ys/BR_HOP;xx-=xs*xs/BR_HOP;yy-=ys*ys/BR_HOP;
    return fmin(1.,xy*xy/fmax(1.,xx*yy));
}
enum br_source br_reference_process(struct br_consumer *r,uint64_t generation,
    uint64_t first,const float hardware[BR_HOP],int valid,uint64_t now,float out[BR_HOP],struct br_decision *d) {
    if(!r||!out||!d)return BR_NONE;
    struct br_context *c=r->ctx;
    int was_locked=r->locked,reset=0,usable=valid&&finite_hop(hardware);
    enum br_source old_source=r->source,source=usable?BR_HARDWARE:BR_NONE;
    uint64_t epoch=br_load64(&c->cap_epoch);
    if(!r->seen||generation!=r->generation||first!=r->next||epoch!=r->epoch||!usable) {
        r->locked=0;r->fill=0;reset=r->seen;
    }
    r->seen=1;r->generation=generation;r->epoch=epoch;
    r->next=first<=BR_MAX_INDEX-BR_HOP?first+BR_HOP:BR_MAX_INDEX;
    if(usable) {
        memmove(r->hardware,r->hardware+BR_HOP,(BR_HISTORY-BR_HOP)*sizeof(float));
        for(unsigned i=0;i<BR_HOP;i++)r->hardware[BR_HISTORY-BR_HOP+i]=hardware[i]*32768.f;
        if(r->fill<BR_HISTORY)r->fill+=BR_HOP;
        memcpy(out,hardware,BR_HOP*sizeof(*out));
    } else memset(out,0,BR_HOP*sizeof(*out));
    struct render_view v;int view_ok=render_view(c,&v);
    if(!view_ok||v.generation!=r->render_generation||v.sequence!=r->render_sequence) {
        if(r->locked||(view_ok&&r->render_sequence&&v.sequence!=r->render_sequence))reset=1;
        r->locked=0;
    }
    if(view_ok){r->render_generation=v.generation;r->render_sequence=v.sequence;}
    if(usable&&first<=BR_MAX_INDEX-BR_HOP&&first+BR_HOP>=BR_HISTORY&&r->fill==BR_HISTORY&&
       view_ok&&fresh(now,v.updated,BR_RENDER_AGE_NS)) {
        uint64_t history_first=first+BR_HOP-BR_HISTORY;
        uint64_t position=0,lo=v.first+BR_RADIUS;
        unsigned required=3*(BR_HISTORY-1)+BR_RADIUS+1;
        if(v.end<required)goto no_software;
        uint64_t hi=v.end-required;
        if(hi<lo)goto no_software;
        double energy=0;int consistent=1;
        for(unsigned i=BR_HISTORY-BR_HOP;i<BR_HISTORY;i++)energy+=(double)r->hardware[i]*r->hardware[i];
        if(r->locked)position=r->position+3*BR_HOP;
        else {
            struct seed seed;
            if(energy<BR_HOP*4.||!get_result(c,&seed)||seed.capture_generation!=generation||
               seed.epoch!=epoch||seed.render_generation!=v.generation||seed.render_sequence!=v.sequence||
               history_first<seed.capture_first||now<seed.started||
               now-seed.started>BR_MAX_JOB_AGE_NS||seed.confidence<.65)goto no_software;
            uint64_t delta=history_first-seed.capture_first;
            if(delta>16000)goto no_software;
            position=seed.render_first+3*delta;
        }
        if(position<lo||position>hi)goto no_software;
        if(energy>=BR_HOP*4.) {
            double best=0;uint64_t best_position=position;
            for(int shift=-12;shift<=12;shift++) {
                if(shift<0&&position<(uint64_t)-shift)continue;
                uint64_t trial=shift<0?position-(uint64_t)-shift:position+(uint64_t)shift;
                if(trial<lo||trial>hi)continue;
                double q=score_current(r,trial,&consistent);
                if(q>best){best=q;best_position=trial;}
            }
            r->confidence=sqrt(best);
            if(best<.65*.65)goto no_software;
            position=best_position;
        } else if(!r->locked)goto no_software;
        /* Bounded 24,704 sample products, normalized only at API boundary. */
        for(unsigned i=0;i<BR_HOP;i++) {
            uint64_t p=position+3*(BR_HISTORY-BR_HOP+i);double value=0;
            for(int tap=0;tap<BR_TAPS;tap++)value+=r->fir[tap]*render_sample(c,p+tap-BR_RADIUS,&consistent);
            out[i]=(float)(value/32768.);
        }
        if(!consistent||!render_unchanged(c,&v)||epoch!=br_load64(&c->cap_epoch)||
           generation!=br_load64(&c->cap_generation)) {
            if(usable)memcpy(out,hardware,BR_HOP*sizeof(*out));
            goto no_software;
        }
        r->position=position;r->locked=1;source=BR_SOFTWARE;
        goto finish;
    }
no_software:
    r->locked=0;
    if(now>=r->request_at) {
        br_add64(&c->requests,1);r->request_at=now+BR_RETRY_NS;
    }
finish:
    if(was_locked!=r->locked||old_source!=source)reset=1;
    r->source=source;
    d->source=source;d->reset_adaptive=reset;d->freeze_adaptation=source==BR_NONE;
    d->confidence=source==BR_SOFTWARE?r->confidence:0.;
    d->capture_generation=generation;d->capture_first=first;
    d->render_generation=view_ok?v.generation:0;
    return source;
}
void br_get_stats(const struct br_context *c,struct br_stats *o) {
    if(!c||!o)return;
#define BR_STAT(n) o->n=br_load64(&c->stats.n)
    BR_STAT(submitted);BR_STAT(queue_drops);BR_STAT(generation_gaps);BR_STAT(jobs_started);
    BR_STAT(jobs_completed);BR_STAT(jobs_cancelled);BR_STAT(jobs_expired);BR_STAT(snapshot_rejects);
    BR_STAT(slices);BR_STAT(max_slice_units);BR_STAT(results);BR_STAT(render_pushes);
#undef BR_STAT
}

#ifdef BR_SCORE_PARITY_MAIN
#include <stdio.h>
#include <assert.h>
static double original_score(const struct acquisition *j,unsigned p,unsigned step,unsigned from) {
    double xy=0,xx=0,yy=0,xs=0,ys=0;unsigned n=0;
    for(unsigned i=from;i<BR_HISTORY;i+=step) {
        double x=j->pilot[i],y=j->pcm[p+3*i];
        xy+=x*y;xx+=x*x;yy+=y*y;xs+=x;ys+=y;n++;
    }
    xy-=xs*ys/n;xx-=xs*xs/n;yy-=ys*ys/n;
    return fmin(1.,xy*xy/fmax(1.,xx*yy));
}
int main(void) {
    struct acquisition *j=calloc(1,sizeof(*j));assert(j);
    uint32_t random=1941361;unsigned comparisons=0;
    const unsigned step[3]={16,1,1},from[3]={0,0,BR_HISTORY-BR_HOP};
    for(unsigned fixture=0;fixture<20;fixture++) {
        for(unsigned i=0;i<BR_SNAPSHOT;i++){
            random=random*1664525u+1013904223u;j->pcm[i]=(int16_t)(random>>16);
        }
        for(unsigned i=0;i<BR_HISTORY;i++) {
            float value=j->pcm[117+3*i];
            j->pilot[i]=fixture==0?0:fixture==1?1500:fixture%2?-.7f*value+15:1.3f*value;
        }
        cache_pilot_statistics(j);
        for(unsigned position=0;position<128;position++)for(unsigned mode=0;mode<3;mode++) {
            double expected=original_score(j,position,step[mode],from[mode]);
            double actual=score_snapshot(j,position,step[mode],from[mode]);
            assert(!memcmp(&expected,&actual,sizeof(actual)));comparisons++;
        }
    }
    printf("{\"result\":\"PASS\",\"bitwise_original_score_comparisons\":%u,\"work_quota\":512,\"time_budget_ns\":500000,\"job_age_ns\":500000000}\n",comparisons);
    free(j);return 0;
}
#endif
