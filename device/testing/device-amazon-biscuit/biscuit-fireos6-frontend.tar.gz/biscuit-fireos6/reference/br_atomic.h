/* SPDX-License-Identifier: MIT
 * Sequential consistency is deliberate for the experimental publication ABI.
 * Atomic payloads plus bounded sequence validation avoid undefined seqlock
 * data races. Relaxing ordering requires separate proof and regression tests.
 */
#ifndef BR_ATOMIC_H
#define BR_ATOMIC_H
#include <stdint.h>
#ifdef _WIN32
#include <windows.h>
typedef volatile LONG64 br_atomic_u64;
typedef volatile LONG br_atomic_u32;
static inline uint64_t br_load64(const br_atomic_u64 *a) { return (uint64_t)InterlockedCompareExchange64((volatile LONG64 *)a,0,0); }
static inline void br_store64(br_atomic_u64 *a,uint64_t v) { InterlockedExchange64(a,(LONG64)v); }
static inline uint64_t br_add64(br_atomic_u64 *a,uint64_t v) { return (uint64_t)InterlockedExchangeAdd64(a,(LONG64)v); }
static inline uint32_t br_load32(const br_atomic_u32 *a) { return (uint32_t)InterlockedCompareExchange((volatile LONG *)a,0,0); }
static inline void br_store32(br_atomic_u32 *a,uint32_t v) { InterlockedExchange(a,(LONG)v); }
static inline int br_atomic_lock_free(void) { return sizeof(void *)==8; }
#else
#include <stdatomic.h>
typedef _Atomic uint64_t br_atomic_u64;
typedef _Atomic uint32_t br_atomic_u32;
static inline uint64_t br_load64(const br_atomic_u64 *a) { return atomic_load_explicit(a,memory_order_seq_cst); }
static inline void br_store64(br_atomic_u64 *a,uint64_t v) { atomic_store_explicit(a,v,memory_order_seq_cst); }
static inline uint64_t br_add64(br_atomic_u64 *a,uint64_t v) { return atomic_fetch_add_explicit(a,v,memory_order_seq_cst); }
static inline uint32_t br_load32(const br_atomic_u32 *a) { return atomic_load_explicit(a,memory_order_seq_cst); }
static inline void br_store32(br_atomic_u32 *a,uint32_t v) { atomic_store_explicit(a,v,memory_order_seq_cst); }
static inline int br_atomic_lock_free(void) { br_atomic_u64 a=0; br_atomic_u32 b=0; return atomic_is_lock_free(&a)&&atomic_is_lock_free(&b); }
#endif
#endif
