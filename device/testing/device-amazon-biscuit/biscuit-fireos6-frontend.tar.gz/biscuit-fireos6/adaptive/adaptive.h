#ifndef FOS6_ADAPTIVE_H
#define FOS6_ADAPTIVE_H
#include "../src/aec.h"
#include <stdint.h>

enum { ADAPTIVE_BEAMS=8, ADAPTIVE_BINS=128, ADAPTIVE_REFS=2,
       ADAPTIVE_TAPS=12, ADAPTIVE_TRAINING_HOPS=625,
       ADAPTIVE_GROUP_HOLD=12, ADAPTIVE_FADE_HOPS=4 };
typedef struct adaptive_state adaptive_state;
typedef struct {
    uint64_t generation;
    unsigned adapt_mask, bypass_mask, protected_mask;
    int selection_enabled, playback_active, reference_valid;
    float speech_confidence;
} adaptive_control;
typedef struct {
    unsigned selected_group, selected_beam, contender_group, contender_hops;
    unsigned adapted_mask, training_mask, protected_mask, reset;
    unsigned trained_hops[ADAPTIVE_BEAMS];
    float group_score[ADAPTIVE_BEAMS], weights[ADAPTIVE_BEAMS];
    float cancellation_power[ADAPTIVE_BEAMS];
} adaptive_report;

adaptive_state *adaptive_create(unsigned initial_beam);
void adaptive_destroy(adaptive_state *s);
void adaptive_reset(adaptive_state *s,uint64_t generation,unsigned initial_beam);
size_t adaptive_state_bytes(void);
/* Single audio-thread owner. No locks, allocation, I/O or clocks per hop.
 * Arrays are contiguous beam-major normalized complex spectra. Buffers must
 * not overlap. Return -1 before mutation on invalid input. A generation
 * mismatch clears old adaptation/history before accepting the new frame.
 * External controls must be from the previous hop (never same-hop DTD).
 * Zero controls preserve the configured beam and freeze learning.
 */
int adaptive_process(adaptive_state *s,const aec_complex *beams,
    const adaptive_control *control,aec_complex *cleaned,aec_complex *merged,
    adaptive_report *report);

/* Algebraic primitives factored for synthetic stock-kernel verification.
 * Each vector contains exactly ADAPTIVE_TAPS complex values. The prediction
 * preserves the stock four-lane reduction; update uses error*conj(reference).
 */
float adaptive_reference_power(float old,aec_complex x);
aec_complex adaptive_kernel_predict(const aec_complex *h,const aec_complex *x);
void adaptive_kernel_update(aec_complex *h,const aec_complex *x,
    aec_complex error,float mu,float psi,float power);
/* Diagnostic copy, not used in the audio path. */
size_t adaptive_copy_weights(const adaptive_state *s,aec_complex *out,size_t n);
#endif
