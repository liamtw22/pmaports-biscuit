/* Portable experimental ARA/group-merger candidate; see CONTRACTS.md.
 * Stock kernel algebra/scaling are verified separately; control and selection
 * policy are explicitly experimental. Never treated as a qualified profile.
 */
#include "adaptive.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

static const unsigned references[8][2]={{3,5},{4,6},{5,7},{0,6},{1,7},{0,2},{1,3},{2,4}};
struct adaptive_state {
    uint64_t generation;
    unsigned initial_beam, selected, contender, contender_hops, fade_remaining;
    unsigned trained[8], valid_hops;
    aec_complex h[8][2][128][12], x[8][128][12];
    float reference_power[8][128], noise[8], signal[8], weight[8], target[8];
    int generation_set, playback;
};

size_t adaptive_state_bytes(void){return sizeof(adaptive_state);}
adaptive_state *adaptive_create(unsigned initial_beam){
    if(initial_beam>=8)return NULL;
    adaptive_state *s=calloc(1,sizeof(*s));
    if(s)adaptive_reset(s,0,initial_beam);
    return s;
}
void adaptive_destroy(adaptive_state *s){free(s);}
void adaptive_reset(adaptive_state *s,uint64_t generation,unsigned initial_beam){
    if(!s||initial_beam>=8)return;
    memset(s,0,sizeof(*s));s->generation=generation;s->generation_set=1;
    s->initial_beam=initial_beam;s->selected=(initial_beam+7)%8;
    s->contender=s->selected;s->weight[initial_beam]=s->target[initial_beam]=1;
}
static float energy(aec_complex v){return v.re*v.re+v.im*v.im;}
float adaptive_reference_power(float old,aec_complex x){
    return old*.9869999885559082f+energy(x)*.013000011444091797f;
}
aec_complex adaptive_kernel_predict(const aec_complex *h,const aec_complex *x){
    float re[4]={0},im[4]={0};
    for(unsigned t=0;t<12;t++){
        unsigned i=t%4;
        im[i]+=h[t].re*x[t].im;re[i]+=h[t].re*x[t].re;
        im[i]+=h[t].im*x[t].re;re[i]-=h[t].im*x[t].im;
    }
    return (aec_complex){(re[0]+re[1])+(re[2]+re[3]),
                         (im[0]+im[1])+(im[2]+im[3])};
}
void adaptive_kernel_update(aec_complex *h,const aec_complex *x,
    aec_complex error,float mu,float psi,float power){
    float scale=mu/(psi+80.f*power);
    aec_complex v={error.re*scale,error.im*scale};
    for(unsigned t=0;t<12;t++){
        h[t].re=(h[t].re+v.re*x[t].re)+v.im*x[t].im;
        h[t].im=(h[t].im+v.im*x[t].re)-v.re*x[t].im;
    }
}
size_t adaptive_copy_weights(const adaptive_state *s,aec_complex *out,size_t n){
    size_t count=sizeof(s->h)/sizeof(aec_complex);
    if(!s||!out||n<count)return 0;
    memcpy(out,s->h,sizeof(s->h));return count;
}
static int valid(const aec_complex *x){
    for(unsigned i=0;i<8*128;i++)
        if(!isfinite(x[i].re)||!isfinite(x[i].im)||fabsf(x[i].re)>1024||fabsf(x[i].im)>1024)return 0;
    return 1;
}
static int truth(int v){return v==0||v==1;}

int adaptive_process(adaptive_state *s,const aec_complex *beams,
    const adaptive_control *c,aec_complex *cleaned,aec_complex *merged,adaptive_report *report){
    if(!s||!beams||!c||!cleaned||!merged||!report||
       (c->adapt_mask|c->bypass_mask|c->protected_mask)>255||
       !truth(c->selection_enabled)||!truth(c->playback_active)||!truth(c->reference_valid)||
       !isfinite(c->speech_confidence)||c->speech_confidence<0||c->speech_confidence>1||!valid(beams))return -1;
    memset(report,0,sizeof(*report));
    if(!s->generation_set||s->generation!=c->generation){
        adaptive_reset(s,c->generation,s->initial_beam);report->reset=1;
    }
    /* Route/playback change requires caller generation change when identity
     * changed. Activity alone resets selection dwell, not learned acoustics. */
    if(s->playback!=c->playback_active){s->contender_hops=0;s->playback=c->playback_active;}
    unsigned adapt=c->adapt_mask&~(c->protected_mask|c->bypass_mask);
    if(c->playback_active&&!c->reference_valid)adapt=0;
    report->protected_mask=c->protected_mask;
    for(unsigned b=0;b<8;b++)for(unsigned k=0;k<128;k++){
        memmove(s->x[b][k]+1,s->x[b][k],11*sizeof(aec_complex));
        aec_complex v=beams[b*128+k];s->x[b][k][0]=v;
        s->reference_power[b][k]=adaptive_reference_power(s->reference_power[b][k],v);
    }
    if(s->valid_hops<12)s->valid_hops++;
    for(unsigned b=0;b<8;b++){
        int update=(adapt&(1u<<b))&&s->valid_hops>=12;
        int excited=0;
        for(unsigned k=0;k<128;k++)if(s->reference_power[references[b][0]][k]>1e-12f||s->reference_power[references[b][1]][k]>1e-12f){excited=1;break;}
        if(!excited)update=0;
        int bypass=(c->bypass_mask&(1u<<b))!=0;
        float in_power=0,out_power=0;
        for(unsigned k=0;k<128;k++){
            aec_complex e=beams[b*128+k], estimate={0,0};
            if(!bypass)for(unsigned r=0;r<2;r++){
                aec_complex z=adaptive_kernel_predict(s->h[b][r][k],s->x[references[b][r]][k]);
                estimate.re+=z.re;estimate.im+=z.im;
            }
            e.re-=estimate.re;e.im-=estimate.im;
            /* Protective bound is policy, not a claim about stock. Reset a
             * divergent bin; do not hide overload by clipping microphone PCM. */
            float input_bound=energy(beams[b*128+k])+s->reference_power[references[b][0]][k]+s->reference_power[references[b][1]][k];
            if(!isfinite(e.re)||!isfinite(e.im)||energy(e)>16.f*input_bound+1e-5f){
                if(update)for(unsigned r=0;r<2;r++)memset(s->h[b][r][k],0,sizeof(s->h[b][r][k]));
                e=beams[b*128+k];
            }
            cleaned[b*128+k]=e;
            if(k>=8&&k<=72){in_power+=energy(beams[b*128+k]);out_power+=energy(e);}
            if(update)for(unsigned r=0;r<2;r++){
                unsigned ref=references[b][r];
                /* Stock psi=2^28 maps to 2^-18 under the verified 2^23
                 * boundary scale. Effective step/gating remain experimental. */
                if(s->reference_power[ref][k]>1e-12f)
                    adaptive_kernel_update(s->h[b][r][k],s->x[ref][k],e,.75f,
                        3.814697265625e-6f,s->reference_power[ref][k]);
            }
        }
        if(update){report->adapted_mask|=1u<<b;if(s->trained[b]<625)s->trained[b]++;}
        if(s->trained[b]<625)report->training_mask|=1u<<b;
        report->trained_hops[b]=s->trained[b];
        report->cancellation_power[b]=(in_power-out_power)/65.f;
        float p=out_power/65.f;
        s->signal[b]=s->signal[b]*.75f+p*.25f;
        /* Noise updates only on externally approved non-speech frames. A
         * floor cannot jump upward while the target is protected. */
        if(update){
            if(s->noise[b]==0)s->noise[b]=p;
            else s->noise[b]=s->noise[b]*.987f+p*.013f;
        }
    }
    for(unsigned g=0;g<8;g++){
        float signal=0,noise=0;
        for(unsigned i=0;i<3;i++){unsigned b=(g+i)%8;signal+=s->signal[b];noise+=s->noise[b];}
        report->group_score[g]=signal/(noise+3e-9f);
    }
    /* Selection requires independent speech evidence and a noise baseline for
     * every group. This prevents initial silence or loud playback claiming a
     * speaker. Hold means consecutive above-margin frames in this candidate. */
    int ready=c->selection_enabled&&c->speech_confidence>=.6f&&
        (!c->playback_active||c->reference_valid);
    for(unsigned b=0;b<8;b++)if(s->noise[b]<=0)ready=0;
    unsigned best=s->selected;
    if(ready)for(unsigned g=0;g<8;g++)if(report->group_score[g]>report->group_score[best])best=g;
    if(ready&&best!=s->selected&&report->group_score[best]>1.26f*report->group_score[s->selected]){
        if(s->contender!=best){s->contender=best;s->contender_hops=1;}
        else if(s->contender_hops<12)s->contender_hops++;
        if(s->contender_hops==12){
            s->selected=best;s->contender_hops=0;s->fade_remaining=4;
            memset(s->target,0,sizeof(s->target));
            for(unsigned i=0;i<3;i++)s->target[(best+i)%8]=1.f/3.f;
        }
    }else{s->contender=s->selected;s->contender_hops=0;}
    if(s->fade_remaining){
        for(unsigned b=0;b<8;b++)s->weight[b]+=(s->target[b]-s->weight[b])/(float)s->fade_remaining;
        s->fade_remaining--;
    }
    for(unsigned k=0;k<128;k++){
        aec_complex v={0,0};
        for(unsigned b=0;b<8;b++){v.re+=s->weight[b]*cleaned[b*128+k].re;v.im+=s->weight[b]*cleaned[b*128+k].im;}
        merged[k]=v;
    }
    report->selected_group=s->selected;report->selected_beam=(s->selected+1)%8;
    report->contender_group=s->contender;report->contender_hops=s->contender_hops;
    memcpy(report->weights,s->weight,sizeof(s->weight));return 0;
}
