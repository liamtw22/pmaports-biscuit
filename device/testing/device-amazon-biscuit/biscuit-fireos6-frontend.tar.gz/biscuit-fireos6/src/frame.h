/* Candidate transport v1: explicit identities; no implicit cross-restart PCM. */
#ifndef BISCUIT_CANDIDATE_FRAME_H
#define BISCUIT_CANDIDATE_FRAME_H
#include <stdint.h>
#include <stdio.h>
#include <string.h>
enum { BF_HEADER=64, BF_RAW24=1, BF_MONO16=2,
       BF_CAPTURE_VALID=1, BF_REFERENCE_VALID=2, BF_MUTED=4,
       BF_REFERENCE_RESET=8, BF_WARMING=16 };
typedef struct {
    uint64_t capture_generation, stream_generation, first_sample, captured_ns;
    uint32_t payload_bytes, frames, format, flags;
} bf_frame;
static uint64_t bf_load(const unsigned char *p,unsigned n) {
    uint64_t v=0;for(unsigned i=0;i<n;i++)v|=(uint64_t)p[i]<<(8*i);return v;
}
static void bf_store(unsigned char *p,uint64_t v,unsigned n) {
    for(unsigned i=0;i<n;i++)p[i]=(unsigned char)(v>>(8*i));
}
/* Returns 1 header, 0 clean EOF, -1 malformed/truncated. */
static int bf_read(FILE *f,bf_frame *h) {
    unsigned char b[BF_HEADER];size_t n=fread(b,1,sizeof(b),f);
    if(!n&&!ferror(f))return 0;
    if(n!=sizeof(b)||memcmp(b,"BMF4",4)||bf_load(b+4,2)!=1||
       bf_load(b+6,2)!=BF_HEADER||bf_load(b+56,4)!=16000||bf_load(b+60,4))return -1;
    h->capture_generation=bf_load(b+8,8);h->stream_generation=bf_load(b+16,8);
    h->first_sample=bf_load(b+24,8);h->captured_ns=bf_load(b+32,8);
    h->payload_bytes=(uint32_t)bf_load(b+40,4);h->frames=(uint32_t)bf_load(b+44,4);
    h->format=(uint32_t)bf_load(b+48,4);h->flags=(uint32_t)bf_load(b+52,4);
    return h->capture_generation&&h->first_sample<=UINT64_MAX-h->frames?1:-1;
}
static int bf_write(FILE *f,const bf_frame *h) {
    unsigned char b[BF_HEADER]={0};memcpy(b,"BMF4",4);bf_store(b+4,1,2);bf_store(b+6,BF_HEADER,2);
    bf_store(b+8,h->capture_generation,8);bf_store(b+16,h->stream_generation,8);
    bf_store(b+24,h->first_sample,8);bf_store(b+32,h->captured_ns,8);
    bf_store(b+40,h->payload_bytes,4);bf_store(b+44,h->frames,4);
    bf_store(b+48,h->format,4);bf_store(b+52,h->flags,4);bf_store(b+56,16000,4);
    return fwrite(b,1,sizeof(b),f)==sizeof(b)?0:-1;
}
#endif
