/* Replay-only scalar AEC_V2 port. Stock units and operation order retained.
 * No process-wide state, locks, IO or allocation in aec_process.
 */
#include "aec.h"
#include "aec_table.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* Replace the built-in step-size schedule with an owner-imported one.
 *
 * The file is 128 little-endian float32, exactly as the stock library stores them.
 * Every invariant the extractor checks is re-checked here, because a table that is
 * merely the right SIZE would silently mistune the canceller rather than fail:
 * strictly increasing, within (0, 1], saturating at exactly 1.0.
 *
 * Call before aec_create(). Returns 0 on success, negative on refusal, and leaves
 * the built-in curve untouched on any refusal.
 */
static int aec_vss_stock = 0;

int aec_vss_load(const char *path)
{
    float loaded[128];
    FILE *f;
    size_t got;
    int i;

    if (!path) return -1;
    f = fopen(path, "rb");
    if (!f) return -2;
    got = fread(loaded, sizeof(float), 128, f);
    if (getc(f) != EOF) { fclose(f); return -3; }   /* longer than 128 entries */
    fclose(f);
    if (got != 128) return -3;
    if (!(loaded[0] > 0.f) || loaded[0] >= 1e-3f) return -4;
    if (loaded[127] != 1.0f) return -4;
    for (i = 0; i < 127; i++)
        if (!(loaded[i] > 0.f) || !(loaded[i] < loaded[i + 1]) || loaded[i + 1] > 1.0f)
            return -4;
    memcpy(aec_vss_table, loaded, sizeof aec_vss_table);
    aec_vss_stock = 1;
    return 0;
}

int aec_vss_is_imported(void) { return aec_vss_stock; }

struct aec_state {
    unsigned mics,refs,training,train_count,total;
    aec_complex h[4][2][128][20],x[2][128][20],xn[2][128][20];
    float rp[2][128],power[128],ep[4][128];
    float fast[4],slow[4],floor[4],ratio[4],minimum[4],history[4][128];
    unsigned cursor[4],low_count,high_count;
    float factor364,factor368,rf,rs,mf,ms,confidence,confidence_out,factors[4];
    unsigned predict,update;
    unsigned adapt_lo,adapt_hi;
};
aec_state *aec_create(unsigned m,unsigned r) {
    if(!m||m>4||!r||r>2)return NULL;
    aec_state *s=calloc(1,sizeof(*s));if(!s)return NULL;
    s->mics=m;s->refs=r;s->adapt_lo=0;s->adapt_hi=127;aec_reset(s);
    return s;
}
void aec_destroy(aec_state *s){free(s);}
void aec_set_adapt_band(aec_state *s,float lo_hz,float hi_hz) {
    /* 128 bins spanning 0..8 kHz: 62.5 Hz per bin. */
    if(!s)return;
    float per=8000.f/128.f;
    int lo=(int)(lo_hz/per+.5f),hi=(int)(hi_hz/per+.5f);
    if(lo<0)lo=0; if(hi>127||hi<=0)hi=127; if(lo>hi)lo=0;
    s->adapt_lo=(unsigned)lo;s->adapt_hi=(unsigned)hi;
}

void aec_reset(aec_state *s) {
    /* The adaptation band is CONFIGURATION, not state: it has to survive the
     * memset like mics/refs do. Losing it left adapt_hi at 0, which made the
     * band guard below reject every bin but 0 and silently disabled
     * adaptation after the first discontinuity. */
    unsigned m=s->mics,r=s->refs,lo=s->adapt_lo,hi=s->adapt_hi;
    memset(s,0,sizeof(*s));
    s->mics=m;s->refs=r;s->adapt_lo=lo;s->adapt_hi=hi?hi:127;
    s->training=1;s->factor364=s->factor368=1;
}
static float power_mean(const float *x,unsigned n) {
    float v=0;for(unsigned i=0;i<n;i++)v+=x[i]*x[i];return n?v/n:0;
}
void aec_levels(aec_state *s,const float *mic,unsigned mn,const float *ref,unsigned rn,aec_control *c) {
    float mp=power_mean(mic,mn),rp=power_mean(ref,rn);
    s->rf=s->rf*.987f+rp*(1.f-.987f);s->rs=s->rs*.999f+rp*(1.f-.999f);
    s->mf=s->mf*.999f+mp*(1.f-.999f);s->ms=s->ms*.999f+mp*(1.f-.999f);
    c->ref_factor=fminf(1,s->rf/5e-7f);c->mic_factor=fminf(1,s->mf/1e-8f);
    c->permit_ref=s->rf>=5e-7f;c->permit_mic=s->mf>=1e-8f;
}
static void energy(aec_state *s,aec_complex e[4][128]) {
    float aggregate=0;
    for(unsigned m=0;m<s->mics;m++) {
        float re=0,im=0;for(unsigned b=6;b<=40;b++){re+=e[m][b].re*e[m][b].re;im+=e[m][b].im*e[m][b].im;}
        float p=(re+im)*(1.f/35.f),a=.9869999885559082f,b=.013000011444091797f;
        if(p>s->fast[m]*1.2000000476837158f){a=.75f;b=.25f;}
        s->fast[m]=s->fast[m]*a+p*b;
        s->slow[m]=s->slow[m]*.9869999885559082f+p*.013000011444091797f;
        s->floor[m]=fminf(s->slow[m],fmaxf(s->floor[m]*1.0010000467300415f,s->floor[m]+1e8f));
        s->history[m][s->cursor[m]]=s->slow[m];s->cursor[m]=(s->cursor[m]+1)%128;
        float sum=0,low=s->history[m][0];
        for(unsigned i=0;i<128;i++){sum+=s->history[m][i];low=fminf(low,s->history[m][i]);}
        aggregate+=sum*(1.f/128.f);
        if((double)low<(double)s->slow[m]/100.)low=s->slow[m];
        s->minimum[m]=low;s->ratio[m]=s->ratio[m]*.75f+(s->fast[m]/(low+1e-6f))*.25f;
    }
    float avg=aggregate/s->mics;
    s->factor368=fmaxf(.9850000143051147f,fminf(1,.9869999885559082f+1.3131324916315634e-9f*(avg-1e5f)));
    s->factor364=fmaxf(0,fminf(1,1.f-1.0101010161633894e-7f*(avg-1e5f)));
    if(avg<=10){s->low_count++;s->high_count=0;}
    else if(avg>=100){s->low_count=0;s->high_count++;}
    if(s->low_count>1251)s->low_count=1251;
    if(s->high_count>1251)s->high_count=1251;
}
static int valid_complex(const aec_complex *x,unsigned n) {
    for(unsigned i=0;i<n;i++)if(!isfinite(x[i].re)||!isfinite(x[i].im)||
        fabsf(x[i].re)>1024||fabsf(x[i].im)>1024)return 0;
    return 1;
}
int aec_process(aec_state *s,const aec_complex *mic,const aec_complex *ref,const aec_control *c,aec_complex *out) {
    if(!s||!c||c->mode<0||c->mode>2||!isfinite(c->mic_factor)||!isfinite(c->ref_factor)||
       c->mic_factor<0||c->mic_factor>1||c->ref_factor<0||c->ref_factor>1||
       !valid_complex(mic,s->mics*128)||!valid_complex(ref,s->refs*128))return -1;
    if(s->training)s->train_count++;
    if(s->train_count>=1875){s->training=0;s->train_count=0;}
    if(s->total++>=225000){s->total=0;s->training=1;s->train_count=0;}
    memset(s->power,0,sizeof(s->power));
    for(unsigned r=0;r<s->refs;r++)for(unsigned b=0;b<128;b++) {
        memmove(s->x[r][b]+1,s->x[r][b],19*sizeof(aec_complex));
        aec_complex v={ref[r*128+b].re*4194304.f,ref[r*128+b].im*4194304.f};s->x[r][b][0]=v;
        float p=v.re*v.re+v.im*v.im;
        s->rp[r][b]=s->rp[r][b]*.9876543283462524f+p*.012345671653747559f;
        s->power[b]+=s->rp[r][b];
    }
    for(unsigned r=0;r<s->refs;r++)for(unsigned b=0;b<128;b++) {
        float scale=1.f/(268435456.f+80.f*s->power[b]);
        for(unsigned t=0;t<20;t++){s->xn[r][b][t].re=s->x[r][b][t].re*scale;s->xn[r][b][t].im=s->x[r][b][t].im*scale;}
    }
    s->predict=!c->bypass;s->update=c->permit_mic&&c->permit_ref&&!c->hold&&!c->bypass;
    aec_complex e[4][128];
    for(unsigned m=0;m<s->mics;m++)for(unsigned b=0;b<128;b++) {
        e[m][b].re=mic[m*128+b].re*8388608.f;e[m][b].im=mic[m*128+b].im*8388608.f;
        if(s->predict)for(unsigned r=0;r<s->refs;r++) {
            /* Stock NEON sums four lanes separately before horizontal addition. */
            float re[4]={0},im[4]={0};
            for(unsigned t=0;t<20;t++) {
                unsigned lane=t%4;aec_complex h=s->h[m][r][b][t],x=s->x[r][b][t];
                im[lane]+=h.im*x.re;re[lane]+=h.re*x.re;
                im[lane]=h.re*x.im+im[lane];re[lane]-=h.im*x.im;
            }
            e[m][b].re-=(re[0]+re[1])+(re[2]+re[3]);e[m][b].im-=(im[0]+im[1])+(im[2]+im[3]);
        }
        float p=e[m][b].re*e[m][b].re+e[m][b].im*e[m][b].im;
        s->ep[m][b]=s->ep[m][b]*.9869999885559082f+p*.013000011444091797f;
        out[m*128+b].re=e[m][b].re*(1.f/8388608.f);out[m*128+b].im=e[m][b].im*(1.f/8388608.f);
    }
    energy(s,e);
    for(unsigned m=0;m<s->mics;m++) {
        float factor;int index;
        if(c->mode==0){index=(int)(c->ref_factor*c->mic_factor*128.f);if(index>127)index=127;factor=s->training?1:aec_vss_table[index];}
        else if(c->mode==1)factor=c->hold?0:(s->training?1:2.f/(1.f+.30000001192092896f*s->ratio[m]));
        else {index=(int)(2.f/(1.f+.30000001192092896f*s->ratio[m])*128.f);if(index>127)index=127;factor=s->training?1:fmaxf(.75f,aec_vss_table[index]);}
        s->factors[m]=factor;
        if(!s->update)continue;
        for(unsigned b=0;b<128;b++) {
            /* Outside the error band the kernel is left alone. */
            if(b<s->adapt_lo||b>s->adapt_hi)continue;
            aec_complex v=e[m][b];float p=v.re*v.re+v.im*v.im;
            if(!s->training&&p>s->ep[m][b]){float g=sqrtf(s->ep[m][b]/p);v.re*=g;v.im*=g;}
            v.re*=factor*.75f;v.im*=factor*.75f;
            for(unsigned r=0;r<s->refs;r++)for(unsigned t=0;t<20;t++) {
                aec_complex x=s->xn[r][b][t],*h=&s->h[m][r][b][t];
                h->re=(h->re+v.re*x.re)+v.im*x.im;
                h->im=(h->im+v.im*x.re)-v.re*x.im;
            }
        }
    }
    return 0;
}
float aec_dtd(aec_state *s,const aec_complex *selected,unsigned channels,const aec_complex *reference,float gain) {
    float metric=0,scale=16.569499969482422f*16.569499969482422f,scaled=(scale*gain)*gain;
    for(unsigned b=4;b<48;b++) {
        float a=0,r=0;
        for(unsigned m=0;m<channels;m++){aec_complex z=selected[m*128+b];a=fmaxf(a,(z.re*z.re+z.im*z.im)*scaled);}
        for(unsigned m=0;m<s->refs;m++){aec_complex z=reference[m*128+b];r=fmaxf(r,(z.re*z.re+z.im*z.im)*scale);}
        metric=fmaxf(metric,a-r);
    }
    float value=(float)log((double)(1.f+metric));
    s->confidence+=(value-s->confidence)*(1.f-.95f);
    s->confidence_out=fminf(1,fmaxf(0,s->confidence));return s->confidence_out;
}
void aec_debug_timer(aec_state *s,unsigned active,unsigned count,unsigned total){s->training=active;s->train_count=count;s->total=total;}
size_t aec_debug(aec_state *s,unsigned item,float *out,size_t capacity) {
    size_t n=0;
#define EMIT(v) do {if(n<capacity)out[n]=(float)(v);n++;}while(0)
    if(item==0)for(unsigned m=0;m<s->mics;m++)for(unsigned r=0;r<s->refs;r++)for(unsigned b=0;b<128;b++)for(unsigned t=0;t<20;t++){EMIT(s->h[m][r][b][t].re);EMIT(s->h[m][r][b][t].im);}
    else if(item==1)for(unsigned r=0;r<s->refs;r++)for(unsigned b=0;b<128;b++)for(unsigned t=0;t<20;t++){EMIT(s->x[r][b][t].re);EMIT(s->x[r][b][t].im);}
    else if(item==2)for(unsigned b=0;b<128;b++){EMIT(s->power[b]);}
    else if(item==3)for(unsigned m=0;m<s->mics;m++){EMIT(s->fast[m]);EMIT(s->slow[m]);EMIT(s->floor[m]);EMIT(s->ratio[m]);EMIT(s->minimum[m]);EMIT(s->factors[m]);}
    else if(item==4){EMIT(s->training);EMIT(s->train_count);EMIT(s->total);EMIT(s->predict);EMIT(s->update);EMIT(s->confidence);EMIT(s->confidence_out);}
#undef EMIT
    return n;
}
