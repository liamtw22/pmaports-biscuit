#ifndef FOS6_AEC_H
#define FOS6_AEC_H
#include <stddef.h>
#include <stdint.h>
typedef struct { float re,im; } aec_complex;
enum { AEC_MICS=4,AEC_REFS=2,AEC_BINS=128,AEC_TAPS=20 };
typedef struct aec_state aec_state;
typedef struct { int mode,permit_mic,permit_ref,hold,bypass; float mic_factor,ref_factor; } aec_control;
/* Step-size schedule. The built-in curve is ours; aec_vss_load() replaces it
 * with an owner-imported stock table. Call before aec_create(). */
int aec_vss_load(const char *path);
int aec_vss_is_imported(void);
/* Restrict adaptation to a frequency band, as stock Fire OS 6 does with its
 * 400-2500 Hz error band. Hz, inclusive; 0 and 8000 mean the full band.
 * Call after aec_create(). Bins outside the band keep their kernels. */
void aec_set_adapt_band(aec_state *s,float lo_hz,float hi_hz);
aec_state *aec_create(unsigned mics,unsigned refs);
void aec_destroy(aec_state *s);
void aec_reset(aec_state *s);
/* Spectra: normalized floats, contiguous [mic/ref][128]. No allocations. */
int aec_process(aec_state *s,const aec_complex *mic,const aec_complex *ref,
                const aec_control *control,aec_complex *out);
void aec_levels(aec_state *s,const float *mic,unsigned mic_samples,
                const float *ref,unsigned ref_samples,aec_control *control);
float aec_dtd(aec_state *s,const aec_complex *selected,unsigned channels,
              const aec_complex *reference,float gain);
/* Offline verification only: read-only flattened state and controlled timer setup. */
size_t aec_debug(aec_state *s,unsigned item,float *out,size_t capacity);
void aec_debug_timer(aec_state *s,unsigned training,unsigned count,unsigned total);
#endif
