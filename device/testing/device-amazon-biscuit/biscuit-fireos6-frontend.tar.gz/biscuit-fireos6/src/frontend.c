/* Fire OS 6 assistant front-end experiment v0.4.0.
 * Isolated candidate: stock-derived kernels plus experimental policy.
 * FFT and HPF structure follows the project's current scalar implementation.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <errno.h>
#ifndef _WIN32
#include <sched.h>
#include <sys/mman.h>
#include <sys/syscall.h>
/* musl stubs sched_setscheduler/sched_getscheduler/sched_getparam to ENOSYS
 * unconditionally - verified on this device, which reports "Function not
 * implemented" even as root - so go to the kernel directly. util-linux chrt
 * does the same. Declared here rather than switching this translation unit to
 * _GNU_SOURCE, which would change what else the headers expose. */
extern long syscall(long, ...);
#endif
#include "aec.h"
#include "frame.h"
#include "../reference/bounded_reference.h"
#include "../vad/dnn_vad.h"
#include "../adaptive/adaptive.h"
#include "../controls/stock_policy.h"
#include "../controls/ara_metrics.h"
#include "../controls/group_policy.h"
#ifdef _WIN32
#include <windows.h>
#include <io.h>
#include <fcntl.h>
#define CLOCK_MONOTONIC 0
#define CLOCK_THREAD_CPUTIME_ID 1
typedef int clockid_t;
#endif
#define N 256
#define HOP 128
#define LEN 768
#define M 4
#define B 8
#define PI 3.14159265358979323846
typedef aec_complex cpx;
static const int channel[M]={1,2,4,5};
static float prototype[LEN],normalizer[HOP],history[M+2][LEN],overlap[B][LEN];
static cpx coefficients[B][N/2][4][M],spectra[4][M][N/2+1];
static float cal[8]={1,1,1,1,1,1,1,1};
static double stamp(clockid_t clock) {
#ifdef _WIN32
    if(clock==CLOCK_THREAD_CPUTIME_ID){FILETIME a,b,k,v;GetThreadTimes(GetCurrentThread(),&a,&b,&k,&v);return (((uint64_t)k.dwHighDateTime<<32)+k.dwLowDateTime+((uint64_t)v.dwHighDateTime<<32)+v.dwLowDateTime)*1e-7;}
    LARGE_INTEGER t,f;QueryPerformanceCounter(&t);QueryPerformanceFrequency(&f);return (double)t.QuadPart/f.QuadPart;
#else
    struct timespec ts;clock_gettime(clock,&ts);return ts.tv_sec+ts.tv_nsec*1e-9;
#endif
}
static void fft(cpx *x,int inverse) {
    for(int i=1,j=0;i<N;i++) {
        int bit=N>>1;for(;j&bit;bit>>=1)j^=bit;j^=bit;
        if(i<j){cpx t=x[i];x[i]=x[j];x[j]=t;}
    }
    for(int len=2;len<=N;len<<=1) {
        float angle=(inverse?2:-2)*PI/len;cpx root={cosf(angle),sinf(angle)};
        for(int i=0;i<N;i+=len) {
            cpx w={1,0};
            for(int j=0;j<len/2;j++) {
                cpx u=x[i+j],t=x[i+j+len/2];
                cpx v={t.re*w.re-t.im*w.im,t.re*w.im+t.im*w.re};
                x[i+j]=(cpx){u.re+v.re,u.im+v.im};x[i+j+len/2]=(cpx){u.re-v.re,u.im-v.im};
                w=(cpx){w.re*root.re-w.im*root.im,w.re*root.im+w.im*root.re};
            }
        }
    }
    if(inverse)for(int i=0;i<N;i++){x[i].re/=N;x[i].im/=N;}
}
static int read_values(const char *path,float *out,size_t expected) {
    FILE *f=fopen(path,"r");if(!f){perror(path);return -1;}
    char line[256];size_t count=0;
    while(fgets(line,sizeof(line),f)) {
        char *p=line,*end;while(*p==' '||*p=='\t')p++;
        if(*p=='\n'||*p=='\r'||*p=='/'||!*p)continue;
        float value=strtof(p,&end);if(end==p||!isfinite(value)||count>=expected){fclose(f);return -1;}
        while(*end==' '||*end=='\t'||*end=='\r'||*end=='\n'||*end==',')end++;
        if(*end){fclose(f);return -1;}
        out[count++]=value;
    }
    int bad=ferror(f);fclose(f);return bad||count!=expected?-1:0;
}
static int assets(const char *dir,int reverse,int conjugate) {
    char path[1024];float raw[32768];
    if(snprintf(path,sizeof(path),"%s/coefs_FilterBank_AnalysisSynthesis_768cvxGLow.cfg",dir)>=(int)sizeof(path)||read_values(path,prototype,LEN))return -1;
    if(snprintf(path,sizeof(path),"%s/coefs_FBFV2_LowLatency_8beams.cfg",dir)>=(int)sizeof(path)||read_values(path,raw,32768))return -1;
    for(int p=0;p<HOP;p++) {
        double energy=0;for(int n=p;n<LEN;n+=HOP)energy+=prototype[n]*prototype[n];
        if(energy<1e-12)return -1;
        normalizer[p]=2*HOP; /* Stock synthesis scales by twice the hop. */
    }
    /* The owner's imported coefficient file is ordered beam/mic/bin/tap/complex,
     * as observed from how the stock loader reads it (32768 tagged floats).
     * The stock runtime's four-lane packing is not the file's packing. */
    for(int b=0;b<B;b++)for(int m=0;m<M;m++)for(int k=0;k<N/2;k++)for(int t=0;t<4;t++) {
        int i=(((b*M+m)*(N/2)+k)*4+t)*2;
        coefficients[b][k][reverse?3-t:t][m]=(cpx){raw[i],conjugate?-raw[i+1]:raw[i+1]};
    }
    return 0;
}
/* Stock's existing 80-Hz high-pass coefficients; no stock +20-dB makeup is
 * assumed for the new MicPreProcess configuration (MicBoostdB=0). */
struct hpf80 { float x1[3], x2[3], y1[3], y2[3]; };

static inline float hpf80_step(struct hpf80 *s, float x)
{
	static const float a1[3] = {
		-1.978964742877471f, -1.920823752121581f, -1.995031240858690f
	};
	static const float a2[3] = {
		 0.980148787818626f,  0.923195725460049f,  0.995935784603137f
	};
	static const float b0[3] = {
		 2.061764283274676f, 12.481101519210988f,  0.036465860122281f
	};
	static const float b1[3] = {
		-4.122862292740000f,-24.961562229700000f, -0.072912904280000f
	};
	static const float b2[3] = {
		 2.061764283274676f, 12.481101519210988f,  0.036465860122281f
	};
	for (int i = 0; i < 3; i++) {
		/* Coefficients use the standard denominator 1 + a1*z^-1 +
		 * a2*z^-2, hence the minus signs in the recurrence. */
		float y = b0[i] * x + b1[i] * s->x1[i] + b2[i] * s->x2[i]
			- a1[i] * s->y1[i] - a2[i] * s->y2[i];
		s->x2[i] = s->x1[i]; s->x1[i] = x;
		s->y2[i] = s->y1[i]; s->y1[i] = y;
		x = y;
	}
	return x;
}

static struct hpf80 hpf[M+2];
static float highpass(int m,float x) {return hpf80_step(&hpf[m],x);}
/* Gap 4: explicit reference/microphone alignment, our analogue of stock Fire OS 6
 * selectAECOutputDelaySamples=168. Positive delays the reference toward the mics,
 * negative delays the mics toward the reference, so one flag sweeps both
 * directions. Applied to the time-domain hop, before the HPF and filterbank, which
 * is where a hardware alignment would sit. */
static float refdelay_tail[256],micdelay_tail[M][256];
static void delay_apply(float *x,float *tail,int d) {
    float tmp[HOP];
    if(d<=0||d>256)return;
    for(int i=0;i<HOP;i++){int k=i-d;tmp[i]=(k>=0)?x[k]:tail[256+k];}
    memmove(tail,tail+HOP,(256-HOP)*sizeof(float));
    memcpy(tail+256-HOP,x,HOP*sizeof(float));
    memcpy(x,tmp,HOP*sizeof(float));
}

static void reset_capture(aec_state *aec) {
    aec_reset(aec);memset(history,0,sizeof(history));memset(hpf,0,sizeof(hpf));
    memset(spectra,0,sizeof(spectra));memset(overlap,0,sizeof(overlap));
}
static int usage(void) {
    fprintf(stderr,"fireos6-v0.4.0 UNQUALIFIED reference/adaptive/lifecycle candidate.\n"
      "Usage: --allow-unqualified --assets DIR [--beam 0..7|--all-beams] [--float32]\n"
      " [--no-aec] [--aec-hold] [--bypass-fbf] [--no-hpf] [--reverse-taps] [--conjugate] [--gain N] [--cal FILE] [--timing FILE]\n"
      " [--framed-input] [--framed-output] [--rendered-reference PATH]\n"
      " [--ref-delay -256..256] [--nl-ref] [--freeze-aec-on-speech] [--vad-file F]\n"
      " [--dnn-vad vad_lite.tflite] [--dnn-lib DIR] [--dnn-threshold 0..1]\n"
      " [--adaptive] [--adapt-mask 0..255] [--protect-mask 0..255] [--select-beam]\n"
      " [--rt-priority 1..99]  SCHED_FIFO + mlockall for this thread; needs root. 45\n"
      "                        matches the biscuit-beamform branch. Fatal if refused.\n"
      "Input: 8-channel S24_3LE/16kHz; output: mono (or 8-beam) S16_LE/16kHz.\n");return 2;
}
/* Take the real-time policy in this process instead of via an external chrt.
 * chrt leaves an exec-race window in which the measured process is still
 * SCHED_OTHER, and it is not something that can ship. Called after all
 * allocation and immediately before the processing loop: mlockall first, while
 * still preemptible, then the policy.
 *
 * Every failure is fatal. Continuing at SCHED_OTHER would label a non-real-time
 * run as real-time, which is worse than not running at all.
 *
 * Only the calling thread is raised. A --rendered-reference worker thread keeps
 * the inherited policy by design: it is background work, not the 8 ms path. */
static int realtime_engage(int priority) {
#ifdef _WIN32
    (void)priority;
    fprintf(stderr,"Real-time scheduling is unsupported on this platform\n");
    return 1;
#else
    struct sched_param param;
    int low=sched_get_priority_min(SCHED_FIFO),high=sched_get_priority_max(SCHED_FIFO);
    if(low<0||high<0){perror("sched_get_priority");return 1;}
    if(priority<low||priority>high){
        fprintf(stderr,"Real-time priority %d outside supported %d..%d\n",priority,low,high);
        return 1;}
    if(mlockall(MCL_CURRENT|MCL_FUTURE)){perror("mlockall");return 1;}
    memset(&param,0,sizeof param);
    param.sched_priority=priority;
    if(syscall(SYS_sched_setscheduler,0,SCHED_FIFO,&param)){perror("sched_setscheduler");return 1;}
    /* Read back rather than trust the call; this line is the run's own evidence. */
    if(syscall(SYS_sched_getscheduler,0)!=SCHED_FIFO){
        fprintf(stderr,"Real-time policy did not take effect\n");return 1;}
    memset(&param,0,sizeof param);
    if(syscall(SYS_sched_getparam,0,&param)||param.sched_priority!=priority){
        fprintf(stderr,"Real-time priority readback mismatch\n");return 1;}
    fprintf(stderr,"RT policy=SCHED_FIFO priority=%d mlockall=current+future\n",priority);
    return 0;
#endif
}

int main(int argc,char **argv) {
#ifdef _WIN32
    _setmode(_fileno(stdin),_O_BINARY);_setmode(_fileno(stdout),_O_BINARY);
#endif
    int no_aec=0,hold_aec=0;
    aec_state *aec=aec_create(4,1);if(!aec)return 1;
    aec_control control={0};
    cpx refspec[128],refspec2[2][128],micin[4][128],micout[4][128],beam_spectra[8][128];
    float mic_time[4][128],ref_time[128],hardware[128];
    cpx cleaned[8][128],merged[128];
    const char *render_path=NULL;int framed_input=0,framed_output=0,adaptive_enabled=0,select_beam=0;
    /* Prototype speech confidence for the beam-group merger. Speech-band energy
     * against a slowly tracked noise floor - NOT stock's DNN VAD, and not qualified.
     * Exists to test whether the merger helps once it is fed at all. */
    int vad_energy=0;float vad_floor=0.f,vad_confidence=0.f;
    int adapt_on_echo=0;
    int freeze_on_speech=0;
    float aec_band_lo=0.f,aec_band_hi=0.f;
    int ref_delay=0,nl_ref=0,freeze_aec=0,prev_speech=0;
    /* Offline only: a per-hop speech confidence computed elsewhere, so a
     * candidate VAD can be measured against the chain before it is
     * implemented in C. float32, one value per hop, native order. */
    const char *vad_path=NULL;float *vad_table=NULL;size_t vad_count=0;
    /* Stock Fire OS 6 DNN VAD. Owner-imported; absent is normal and falls back
     * to the energy prototype. It reads the MERGED BEAM, which this loop
     * produces after the canceller it gates, so its verdict necessarily
     * applies to the NEXT hop - 8 ms, far shorter than any utterance. */
    const char *dnn_model=NULL,*dnn_libdir="/usr/lib/biscuit-tflite";
    dnn_vad *dnn=NULL;float dnn_prob=0.f,dnn_history[LEN];
    /* The level the model was characterised at, held FIXED so re-deriving the
     * output gain cannot silently move the VAD operating point. */
    const float dnn_ref_gain=4.768f;unsigned long dnn_fallbacks=0;
    /* The chain tests speech_confidence >= 0.6 throughout. The DNN's mean
     * probability in speech on the merged beam is 0.18, so 0.6 sits far out on
     * its tail and would gate almost nothing. Its verdict is therefore made
     * binary at a threshold of its own, swept offline: 0.10/0.20/0.30/0.50/0.70
     * all beat the energy prototype level-matched, 0.30 best. */
    float dnn_threshold=0.30f;
    unsigned long vad_hops=0,vad_above=0,vad_group_changes=0;float vad_max=0.f;unsigned vad_last_group=0;
    unsigned vad_hold_max=0;float vad_ratio_max=0.f;unsigned long vad_margin_hits=0;
    unsigned adapt_mask=0,protect_mask=0;int stock_observer=0;
    stock_policy_state observer_levels;ara_metrics_state observer_metrics;
    unsigned long observer_hops=0,observer_groups=0,observer_errors=0;
    stock_policy_init(&observer_levels);ara_metrics_init(&observer_metrics);

    const char *dir=NULL,*timing_path=NULL,*cal_path=NULL;int allowed=0,beam=0,all=0,floating=0,bypass=0,no_hpf=0,reverse=0,conjugate=0;float gain=1;
    int rt_priority=0;
    for(int i=1;i<argc;i++) {
        if(!strcmp(argv[i],"--allow-unqualified"))allowed=1;
        else if(!strcmp(argv[i],"--framed-input"))framed_input=1;
        else if(!strcmp(argv[i],"--framed-output"))framed_output=1;
        else if(!strcmp(argv[i],"--adaptive"))adaptive_enabled=1;
        else if(!strcmp(argv[i],"--stock-observer"))stock_observer=1;
        else if(!strcmp(argv[i],"--vad-energy"))vad_energy=1;
        else if(!strcmp(argv[i],"--adapt-on-echo"))adapt_on_echo=1;
        else if(!strcmp(argv[i],"--freeze-on-speech"))freeze_on_speech=1;
        else if(!strcmp(argv[i],"--nl-ref"))nl_ref=1;
        else if(!strcmp(argv[i],"--freeze-aec-on-speech"))freeze_aec=1;
        else if(!strcmp(argv[i],"--vad-file")&&i+1<argc)vad_path=argv[++i];
        else if(!strcmp(argv[i],"--dnn-vad")&&i+1<argc)dnn_model=argv[++i];
        else if(!strcmp(argv[i],"--dnn-lib")&&i+1<argc)dnn_libdir=argv[++i];
        else if(!strcmp(argv[i],"--dnn-threshold")&&i+1<argc){char *end;
            dnn_threshold=strtof(argv[++i],&end);
            if(*end||!(dnn_threshold>0.f)||dnn_threshold>1.f)return usage();}
        else if(!strcmp(argv[i],"--ref-delay")&&i+1<argc){char *end;
            long d=strtol(argv[++i],&end,10);
            if(*end||d<-256||d>256)return usage();ref_delay=(int)d;}
        else if(!strcmp(argv[i],"--aec-err-band")&&i+1<argc){
            if(sscanf(argv[++i],"%f:%f",&aec_band_lo,&aec_band_hi)!=2)return usage();}
        else if(!strcmp(argv[i],"--select-beam"))select_beam=1;
        else if(!strcmp(argv[i],"--rendered-reference")&&i+1<argc)render_path=argv[++i];
        else if((!strcmp(argv[i],"--adapt-mask")||!strcmp(argv[i],"--protect-mask"))&&i+1<argc){
            int protect=!strcmp(argv[i],"--protect-mask");char *end;long mask=strtol(argv[++i],&end,10);
            if(*end||mask<0||mask>255){return usage();}if(protect)protect_mask=(unsigned)mask;else adapt_mask=(unsigned)mask;}
        else if(!strcmp(argv[i],"--no-aec"))no_aec=1;
        else if(!strcmp(argv[i],"--aec-hold"))hold_aec=1;
        else if(!strcmp(argv[i],"--all-beams"))all=1;
        else if(!strcmp(argv[i],"--float32"))floating=1;
        else if(!strcmp(argv[i],"--bypass-fbf"))bypass=1;
        else if(!strcmp(argv[i],"--no-hpf"))no_hpf=1;
        else if(!strcmp(argv[i],"--reverse-taps"))reverse=1;
        else if(!strcmp(argv[i],"--conjugate"))conjugate=1;
        else if(!strcmp(argv[i],"--assets")&&i+1<argc)dir=argv[++i];
        else if(!strcmp(argv[i],"--timing")&&i+1<argc)timing_path=argv[++i];
        else if(!strcmp(argv[i],"--cal")&&i+1<argc)cal_path=argv[++i];
        else if(!strcmp(argv[i],"--beam")&&i+1<argc){char *end;beam=strtol(argv[++i],&end,10);if(*end||beam<0||beam>=B)return usage();}
        else if(!strcmp(argv[i],"--gain")&&i+1<argc){char *end;gain=strtof(argv[++i],&end);if(*end||!isfinite(gain)||gain<=0||gain>32)return usage();}
        else if(!strcmp(argv[i],"--rt-priority")&&i+1<argc){char *end;long v=strtol(argv[++i],&end,10);if(*end||v<1||v>99)return usage();rt_priority=(int)v;}
        else return usage();
    }
    if(!allowed||!dir)return usage();
    if(stock_observer&&!adaptive_enabled)return usage();
    /* The refusal stands unless something is actually producing confidence. */
    if(select_beam&&!vad_energy){fprintf(stderr,"Selection requires a qualified per-hop confidence source; unavailable in this CLI.\n");return 2;}
    if(select_beam&&vad_energy)fprintf(stderr,"WARNING: selection driven by the UNQUALIFIED energy VAD prototype\n");
    if((framed_output&&(all||floating))||((select_beam||adapt_mask||protect_mask)&&!adaptive_enabled)||
       (adaptive_enabled&&bypass)||(render_path&&!framed_input))return usage();
    if(assets(dir,reverse,conjugate)){fprintf(stderr,"Invalid experimental assets\n");return 1;}
    /* The AEC step-size schedule is an ordinary imported asset: the built-in
     * curve is ours and always works, and the owner can supply the stock one
     * alongside the other Fire OS 6 files. Absence is normal, not an error; a
     * malformed table is refused rather than silently mistuning the canceller.
     * Loaded before aec_create(), so the 8 ms path never branches on it. */
    /* Stock Fire OS 6 restricts the AEC error band to 400-2500 Hz; we adapt
     * the full band unless told otherwise. Set after parsing, before any
     * audio is processed. */
    if(aec_band_hi>0.f)aec_set_adapt_band(aec,aec_band_lo,aec_band_hi);
    if(dnn_model){
        dnn=dnn_vad_create(dnn_model,dnn_libdir);
        if(!dnn){fprintf(stderr,"dnn-vad: cannot load %s from %s; falling back to the energy prototype\n",dnn_model,dnn_libdir);
            /* The message has to be true: without this the chain ran with NO
             * VAD at all, which is worse than either option. */
            vad_energy=1;}
        else{vad_energy=1;memset(dnn_history,0,sizeof(dnn_history));}
    }
    if(vad_path){FILE *vf=fopen(vad_path,"rb");
        if(!vf){fprintf(stderr,"cannot open --vad-file\n");return 1;}
        fseek(vf,0,SEEK_END);long vb=ftell(vf);fseek(vf,0,SEEK_SET);
        if(vb<=0||vb%(long)sizeof(float)){fclose(vf);fprintf(stderr,"bad --vad-file size\n");return 1;}
        vad_count=(size_t)vb/sizeof(float);vad_table=malloc((size_t)vb);
        if(!vad_table||fread(vad_table,1,(size_t)vb,vf)!=(size_t)vb){fclose(vf);
            fprintf(stderr,"cannot read --vad-file\n");return 1;}
        fclose(vf);vad_energy=1;}
    /* Gap 2: stock configures two AEC references on both generations. Its second
     * is the other channel of the stereo pre-DAC playback tap, which our capture
     * does not carry. The only second reference available to us is a NONLINEAR
     * function of the one we have, which targets the part of the echo a linear
     * canceller provably cannot remove. */
    if(nl_ref){aec_destroy(aec);aec=aec_create(4,2);if(!aec)return 1;
        if(aec_band_hi>0.f)aec_set_adapt_band(aec,aec_band_lo,aec_band_hi);}
    {char vss[512];int rc;
     if(snprintf(vss,sizeof(vss),"%s/aec_vss_table.bin",dir)<(int)sizeof(vss)){
         rc=aec_vss_load(vss);
         if(rc<0&&rc!=-2){fprintf(stderr,"vss table at %s is not usable (%d)\n",vss,rc);return 1;}
     }}
    if(cal_path) {
        FILE *f=fopen(cal_path,"r");if(!f){perror(cal_path);return 1;}
        for(int i=0;i<7;i++)if(fscanf(f,"%f",&cal[i])!=1||!isfinite(cal[i])||cal[i]<=0||cal[i]>8){fclose(f);return 1;}
        fclose(f);
    }
    FILE *timing=NULL;if(timing_path){timing=fopen(timing_path,"wx");if(!timing){perror(timing_path);return 1;}fprintf(timing,"hop\tcompute_wall_us\tcompute_cpu_us\tinput_wait_us\toutput_wait_us\n");}
    uint8_t input[HOP*8*3];float output[HOP*B];int16_t pcm[HOP*B];
    if(timing)setvbuf(timing,NULL,_IOLBF,0);
    struct br_context *reference=br_create();struct br_consumer *consumer=reference?br_consumer_create(reference):NULL;
    struct br_thread *worker=render_path&&reference?br_thread_start(reference,render_path):NULL;
    adaptive_state *adaptive=adaptive_enabled?adaptive_create((unsigned)beam):NULL;
    if(!consumer||(render_path&&!worker)||(adaptive_enabled&&!adaptive)){fprintf(stderr,"Candidate initialization failed\n");return 1;}
    if(rt_priority&&realtime_engage(rt_priority))return 1;
    fprintf(stderr,"READY fireos6-v0.4.0 vss=%s vad=%s selection=%s\n",
            aec_vss_is_imported()?"imported":"pmos",
            dnn?"dnn-stock":vad_table?"external-file":vad_energy?"energy-prototype":"none",
            select_beam?"merged-groups":"single-beam");fflush(stderr);
    unsigned long hops=0,clipped=0,missed=0;double wall_sum=0,wall_max=0,cpu_sum=0;
    int channels=all?B:1;size_t bytes=0;double read_start=stamp(CLOCK_MONOTONIC);
    uint64_t previous_capture=0,expected_sample=0,stream_generation=0,resets=0,reference_resets=0,stale_capture_hops=0;
    unsigned warming=0;int previous_muted=-1,previous_valid=-1;
    unsigned long software_hops=0,hardware_hops=0,no_reference_hops=0;
    for(;;) {
        bf_frame frame={1,0,(uint64_t)hops*HOP,0,sizeof(input),HOP,BF_RAW24,BF_CAPTURE_VALID|BF_REFERENCE_VALID};
        if(framed_input){int rc=bf_read(stdin,&frame);if(!rc)break;
            if(rc<0||frame.payload_bytes!=sizeof(input)||frame.frames!=HOP||frame.format!=BF_RAW24||(frame.flags&~7u)){
                fprintf(stderr,"Invalid capture frame\n");return 1;}}
        bytes=fread(input,1,sizeof(input),stdin);
        if(bytes!=sizeof(input)){if(!bytes&&!framed_input&&!ferror(stdin))break;fprintf(stderr,"Truncated capture payload\n");return 1;}
        double start=stamp(CLOCK_MONOTONIC),cpu_start=stamp(CLOCK_THREAD_CPUTIME_ID);
        uint64_t now=br_now_ns();
        if(render_path&&(!frame.captured_ns||frame.captured_ns>now||now-frame.captured_ns>BR_MAX_JOB_AGE_NS)){
            frame.flags&=~(BF_CAPTURE_VALID|BF_REFERENCE_VALID);stale_capture_hops++;}
        int muted=(frame.flags&BF_MUTED)!=0,valid=(frame.flags&BF_CAPTURE_VALID)!=0;
        int discontinuity=frame.capture_generation!=previous_capture||frame.first_sample!=expected_sample||muted!=previous_muted||valid!=previous_valid;
        if(discontinuity){reset_capture(aec);stream_generation++;warming=6;resets++;
            if(dnn){dnn_vad_reset(dnn);memset(dnn_history,0,sizeof(dnn_history));dnn_prob=0.f;}
            if(adaptive)adaptive_reset(adaptive,stream_generation,(unsigned)beam);}
        if(stock_observer&&discontinuity){stock_policy_init(&observer_levels);ara_metrics_init(&observer_metrics);}
        previous_capture=frame.capture_generation;expected_sample=frame.first_sample+HOP;
        previous_muted=muted;previous_valid=valid;
        if(!valid||muted)memset(input,0,sizeof(input));
        for(int i=0;i<HOP;i++){const uint8_t *p=input+(i*8+7)*3;int32_t v=p[0]|p[1]<<8|p[2]<<16;
            if(v&0x800000){v-=0x1000000;}hardware[i]=v/8388608.f;}
        int refvalid=valid&&!muted&&(frame.flags&BF_REFERENCE_VALID);
        if(worker)br_capture_submit(reference,frame.capture_generation,frame.first_sample,hardware,refvalid,frame.captured_ns);
        struct br_decision decision={0};
        br_reference_process(consumer,frame.capture_generation,frame.first_sample,hardware,refvalid,now,ref_time,&decision);
        if(decision.source==BR_SOFTWARE)software_hops++;else if(decision.source==BR_HARDWARE)hardware_hops++;else no_reference_hops++;
        if(decision.reset_adaptive){aec_reset(aec);memset(history[M],0,sizeof(history[M]));memset(history[M+1],0,sizeof(history[M+1]));
            memset(&hpf[M],0,sizeof(hpf[M]));warming=6;reference_resets++;if(adaptive)adaptive_reset(adaptive,stream_generation,(unsigned)beam);}
        if(stock_observer&&decision.reset_adaptive){stock_policy_init(&observer_levels);ara_metrics_init(&observer_metrics);}
        memmove(spectra[1],spectra[0],3*M*(N/2+1)*sizeof(cpx));
        for(int m=0;m<M;m++) {
            float unpacked[HOP];
            memmove(history[m],history[m]+HOP,(LEN-HOP)*sizeof(float));
            for(int i=0;i<HOP;i++) {
                const uint8_t *p=input+(i*8+channel[m])*3;
                int32_t v=p[0]|p[1]<<8|p[2]<<16;if(v&0x800000)v-=0x1000000;
                unpacked[i]=v/8388608.0f*cal[channel[m]];
            }
            if(ref_delay<0)delay_apply(unpacked,micdelay_tail[m],-ref_delay);
            for(int i=0;i<HOP;i++) {
                float x=unpacked[i];
                mic_time[m][i]=x;
                history[m][LEN-HOP+i]=no_hpf?x:highpass(m,x);
            }
            cpx x[N];for(int k=0;k<N;k++){float v=0;for(int p=0;p<LEN/N;p++)v+=history[m][k+p*N]*prototype[k+p*N];x[(k+1)%N]=(cpx){v,0};}
            /* Stock reverses the folded vector then conjugates its FFT,
             * equivalent to this one-sample circular shift before our FFT. */
            fft(x,0);memcpy(spectra[0][m],x,(N/2+1)*sizeof(cpx));
        }
        if(ref_delay>0)delay_apply(ref_time,refdelay_tail,ref_delay);
        memmove(history[M],history[M]+HOP,(LEN-HOP)*sizeof(float));
        for(int i=0;i<HOP;i++) {
            history[M][LEN-HOP+i]=no_hpf?ref_time[i]:highpass(M,ref_time[i]);
        }
        cpx rx[N];
        for(int k=0;k<N;k++){float v=0;for(int p=0;p<3;p++)v+=history[M][k+p*N]*prototype[k+p*N];rx[(k+1)%N]=(cpx){v,0};}
        fft(rx,0);memcpy(refspec,rx,sizeof(refspec));
        memcpy(refspec2[0],refspec,sizeof(refspec));
        if(nl_ref) {
            /* Signed square: the memoryless odd expansion that models the
             * compression this amplifier and driver actually apply. */
            memmove(history[M+1],history[M+1]+HOP,(LEN-HOP)*sizeof(float));
            for(int i=0;i<HOP;i++) {
                float r=ref_time[i],nl=r*fabsf(r);
                history[M+1][LEN-HOP+i]=no_hpf?nl:highpass(M+1,nl);
            }
            cpx nx[N];
            for(int k=0;k<N;k++){float v=0;for(int p=0;p<3;p++)v+=history[M+1][k+p*N]*prototype[k+p*N];nx[(k+1)%N]=(cpx){v,0};}
            fft(nx,0);memcpy(refspec2[1],nx,128*sizeof(cpx));
        }
        for(int m=0;m<M;m++)memcpy(micin[m],spectra[0][m],128*sizeof(cpx));
        if(dnn){vad_confidence=dnn_prob>=dnn_threshold?1.f:0.f;prev_speech=vad_confidence>=.6f;}
        /* Double-talk freeze for the CANCELLER. --freeze-on-speech gates only
         * the adaptive stage; the AEC kept adapting through near-end speech and
         * subtracting it. The VAD reads beam_spectra, which is downstream of this
         * point, so the flag necessarily arrives one hop (8 ms) late - far shorter
         * than any utterance. */
        control.hold=hold_aec||warming||decision.freeze_adaptation||(freeze_aec&&prev_speech);
        control.bypass=no_aec;
        if(stock_observer&&valid&&!muted&&decision.source!=BR_NONE){
            /* Corresponding diagnostic input only: exact stock preprocessing,
             * calibration and makeup-gain parity are not yet established. */
            float mp=0,rp=0;for(int m=0;m<M;m++)for(int i=0;i<HOP;i++)mp+=mic_time[m][i]*mic_time[m][i];
            for(int i=0;i<HOP;i++)rp+=ref_time[i]*ref_time[i];
            if(stock_policy_levels(&observer_levels,mp/(M*HOP),rp/HOP)||
               stock_policy_probability(&observer_levels,observer_levels.microphone_slow,0)<0){observer_errors++;stock_policy_init(&observer_levels);}
        }
        aec_levels(aec,&mic_time[0][0],4*128,ref_time,128,&control);
        if(aec_process(aec,&micin[0][0],nl_ref?&refspec2[0][0]:refspec,&control,&micout[0][0])){fprintf(stderr,"Invalid AEC input/state\n");return 1;}
        for(int m=0;m<M;m++)memcpy(spectra[0][m],micout[m],128*sizeof(cpx));
        int beam_count=adaptive_enabled?B:channels;
        for(int out=0;out<beam_count;out++) {
            int b=(adaptive_enabled||all)?out:beam;cpx y[N];memset(y,0,sizeof(y));
            for(int k=0;k<N/2;k++) {
                if(bypass)y[k]=spectra[0][0][k];
                else for(int t=0;t<4;t++)for(int m=0;m<M;m++) {
                    cpx h=coefficients[b][k][t][m],x=spectra[t][m][k];
                    y[k].re+=h.re*x.re-h.im*x.im;y[k].im+=h.re*x.im+h.im*x.re;
                }
            }
            memcpy(beam_spectra[out],y,128*sizeof(cpx));
        }
        if(dnn){
            /* Already set above from the previous hop; nothing to do. */
        } else if(vad_table){
            /* Supplied externally; the energy estimator below is bypassed. */
            vad_confidence=(size_t)hops<vad_count?vad_table[hops]:0.f;
        } else if(vad_energy){
            /* Speech band only: bins 3..27 is roughly 375 Hz - 3.4 kHz at 125 Hz/bin. */
            float e=0.f;
            for(int k=3;k<28;k++){float best=0.f;
                for(int b=0;b<8;b++){cpx v=beam_spectra[b][k];
                    float p=v.re*v.re+v.im*v.im;if(p>best)best=p;}
                e+=best;}
            /* Fast to rise, slow to fall: the floor should track noise, not speech. */
            if(vad_floor<=0.f)vad_floor=e;
            else if(e<vad_floor)vad_floor+=0.05f*(e-vad_floor);
            else vad_floor+=0.0005f*(e-vad_floor);
            float snr=10.f*log10f((e+1e-20f)/(vad_floor+1e-20f));
            vad_confidence=(snr-6.f)/12.f;
            if(vad_confidence<0.f)vad_confidence=0.f;
            if(vad_confidence>1.f)vad_confidence=1.f;
        }
        if(!dnn)prev_speech=vad_energy&&vad_confidence>=.6f;
        if(adaptive){adaptive_control ac={0};ac.generation=stream_generation;
            /* Adaptation earns its place only against an echo. With no playback
             * there is nothing to cancel and adapting the output beam just erodes
             * the speech - measured as 19/20 -> 15/20 in a quiet room. */
            /* Classic double-talk handling: do not let the canceller adapt
             * while the user is talking, or it learns the speech and
             * subtracts it. This is what stock's ARA_V2/AECARAUtilsV2 do,
             * and the only thing the prototype VAD is really needed for. */
            int _speech=freeze_on_speech&&vad_energy&&vad_confidence>=.6f;
            ac.adapt_mask=(warming||!valid||muted||_speech||
                (adapt_on_echo&&!control.permit_ref))?0:adapt_mask;
            ac.protected_mask=protect_mask;
            ac.selection_enabled=select_beam&&!warming&&valid&&!muted;
            ac.speech_confidence=vad_energy?vad_confidence:0.f;
            if(vad_energy){vad_hops++;if(vad_confidence>=.6f)vad_above++;if(vad_confidence>vad_max)vad_max=vad_confidence;}
            ac.reference_valid=decision.source!=BR_NONE;ac.playback_active=control.permit_ref;
            adaptive_report report;
            if(adaptive_process(adaptive,&beam_spectra[0][0],&ac,&cleaned[0][0],merged,&report)){
                fprintf(stderr,"Invalid adaptive input/state\n");return 1;}
            if(vad_energy&&report.selected_group!=vad_last_group){vad_group_changes++;vad_last_group=report.selected_group;}
            if(vad_energy&&vad_confidence>=.6f){
                if(report.contender_hops>vad_hold_max)vad_hold_max=report.contender_hops;
                float sel=report.group_score[report.selected_group],b=0.f;
                for(unsigned g=0;g<8;g++)if(report.group_score[g]>b)b=report.group_score[g];
                float r=sel>0.f?b/sel:0.f;
                if(r>vad_ratio_max)vad_ratio_max=r;
                if(r>1.26f)vad_margin_hits++;
            }
        }
        if(stock_observer&&valid&&!muted){
            ara_metrics_report mr;float group_metrics[8],weights[8];
            if(ara_metrics_step(&observer_metrics,&cleaned[0][0],&mr)){observer_errors++;ara_metrics_init(&observer_metrics);}
            else{observer_hops++;
            if(!stock_group_observe(mr.merger_numerator,mr.merger_denominator,((unsigned)beam+7)%8,group_metrics,weights))observer_groups++;}
            /* Does not select a beam, change gain, or permit adaptation. */
        }
        for(int out=0;out<channels;out++) {
            int b=all?out:beam;cpx y[N];memset(y,0,sizeof(y));
            const cpx *source=adaptive?(all?cleaned[out]:select_beam?merged:cleaned[beam]):beam_spectra[out];
            memcpy(y,source,128*sizeof(cpx));
            if(bypass)y[N/2]=spectra[0][0][N/2];
            for(int k=N/2+1;k<N;k++)y[k]=(cpx){y[N-k].re,-y[N-k].im};
            fft(y,1);
            for(int i=0;i<LEN;i++)overlap[b][i]+=y[i%N].re*prototype[i];
            for(int i=0;i<HOP;i++) {
                float v=overlap[b][i]*normalizer[i]*gain;
                if(!valid||muted)v=0;
                if(!isfinite(v)){fprintf(stderr,"Nonfinite DSP output\n");return 1;}
                output[i*channels+out]=v;
                if(v>1){v=1;clipped++;}if(v<-1){v=-1;clipped++;}
                pcm[i*channels+out]=(int16_t)lrintf(v*32767);
            }
            memmove(overlap[b],overlap[b]+HOP,(LEN-HOP)*sizeof(float));memset(overlap[b]+LEN-HOP,0,HOP*sizeof(float));
        }
        if(dnn) {
            /* Analyse the MERGED BEAM we just produced, exactly as the offline
             * characterisation did: the synthesised output at the reference
             * gain, through this same 768-tap prototype, bins 0..63 linear.
             *
             * Taken from output[] rather than the pre-synthesis spectrum
             * because that is what was measured, and because stock's DNN VAD
             * carries its own FilterBank block - which only makes sense for an
             * input it re-analyses in the time domain.
             */
            float scale=dnn_ref_gain/(gain>0.f?gain:1.f),mag[64];
            cpx dx[N];
            memmove(dnn_history,dnn_history+HOP,(LEN-HOP)*sizeof(float));
            for(int i=0;i<HOP;i++)dnn_history[LEN-HOP+i]=output[i*channels]*scale;
            for(int k=0;k<N;k++){float v=0;for(int q=0;q<LEN/N;q++)v+=dnn_history[k+q*N]*prototype[k+q*N];dx[(k+1)%N]=(cpx){v,0};}
            fft(dx,0);
            for(int k=0;k<64;k++)mag[k]=sqrtf(dx[k].re*dx[k].re+dx[k].im*dx[k].im);
            float pr=dnn_vad_process(dnn,mag);
            if(pr>=0.f)dnn_prob=pr;
            else{dnn_fallbacks++;dnn_prob=0.f;}
        }
        aec_dtd(aec,&beam_spectra[0][0],(unsigned)beam_count,refspec,1.f);
        double end=stamp(CLOCK_MONOTONIC),cpu=stamp(CLOCK_THREAD_CPUTIME_ID)-cpu_start,wall=end-start;
        wall_sum+=wall;cpu_sum+=cpu;if(wall>wall_max)wall_max=wall;if(wall>.008)missed++;
        size_t count=HOP*channels;
        if(framed_output){bf_frame emitted=frame;emitted.stream_generation=stream_generation;
            emitted.payload_bytes=HOP*2;emitted.format=BF_MONO16;
            emitted.flags=(frame.flags&5u)|(decision.source!=BR_NONE?BF_REFERENCE_VALID:0)|
                (decision.reset_adaptive?BF_REFERENCE_RESET:0)|(warming?BF_WARMING:0);
            if(bf_write(stdout,&emitted))return 1;}
        if(fwrite(floating?(void*)output:(void*)pcm,floating?sizeof(float):sizeof(int16_t),count,stdout)!=count)return 1;
        if(fflush(stdout))return 1;
        double sent=stamp(CLOCK_MONOTONIC);
        if(timing)fprintf(timing,"%lu\t%.3f\t%.3f\t%.3f\t%.3f\n",hops,wall*1e6,cpu*1e6,(start-read_start)*1e6,(sent-end)*1e6);
        if(warming){warming--;}hops++;read_start=stamp(CLOCK_MONOTONIC);
    }
    if(vad_energy)fprintf(stderr,"VAD hops=%lu above0.6=%lu max=%.3f group_changes=%lu hold_max=%u best/sel_max=%.2f margin_hits=%lu\n",
        vad_hops,vad_above,vad_max,vad_group_changes,vad_hold_max,vad_ratio_max,vad_margin_hits);
    if(timing)fclose(timing);
    if(dnn){unsigned long dh=0,de=0;dnn_vad_stats(dnn,&dh,&de);
      fprintf(stderr,"DNN VAD hops=%lu errors=%lu fallbacks=%lu\n",dh,de,dnn_fallbacks);}
    fprintf(stderr,"{\"capture_resets\":%llu,\"reference_resets\":%llu,\"software_hops\":%lu,\"hardware_hops\":%lu,\"no_reference_hops\":%lu}\n",
      (unsigned long long)resets,(unsigned long long)reference_resets,software_hops,hardware_hops,no_reference_hops);
    if(ferror(stdin)){fprintf(stderr,"Truncated input: %zu trailing bytes\n",bytes);return 1;}
    fprintf(stderr,"{\"profile\":\"fireos6-v0.4.0\",\"qualified\":false,\"hops\":%lu,\"channels\":%d,\"clipped\":%lu,\"compute_mean_us\":%.3f,\"compute_max_us\":%.3f,\"compute_cpu_mean_us\":%.3f,\"deadline_misses_8ms\":%lu}\n",hops,channels,clipped,1e6*wall_sum/(hops?hops:1),1e6*wall_max,1e6*cpu_sum/(hops?hops:1),missed);
    fprintf(stderr,"{\"stock_observer_hops\":%lu,\"stock_group_observations\":%lu,\"stock_observer_errors\":%lu,\"stock_controls_enabled\":false}\n",observer_hops,observer_groups,observer_errors);
    struct br_stats refstats;br_get_stats(reference,&refstats);
    fprintf(stderr,"{\"reference_queue_drops\":%llu,\"reference_jobs_cancelled\":%llu,\"reference_jobs_expired\":%llu,\"reference_max_slice_units\":%llu,\"reference_results\":%llu,\"stale_capture_hops\":%llu}\n",
      (unsigned long long)refstats.queue_drops,(unsigned long long)refstats.jobs_cancelled,
      (unsigned long long)refstats.jobs_expired,(unsigned long long)refstats.max_slice_units,
      (unsigned long long)refstats.results,(unsigned long long)stale_capture_hops);
    br_thread_stop(worker);br_consumer_destroy(consumer);br_destroy(reference);
    if(adaptive){adaptive_destroy(adaptive);}aec_destroy(aec);
    return 0;
}
