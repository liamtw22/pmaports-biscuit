Third-party licences: TensorFlow Lite runtime (/usr/lib/biscuit-tflite)
=======================================================================

These libraries are the TensorFlow Lite 2.17.0 C API, built by this project
for aarch64 musl because the wake-word packages only ship an x86-64 glibc
build. None of the code in these libraries was written by this project, and
none of it comes from Amazon. Every component below is unmodified upstream
source at the commit that TensorFlow 2.17.0's CMake build pins. The one
exception is a build fix in flatbuffers, described under "How it was built".

Component      Version (commit)                          Licence          Compiled into                          Licence text
-------------  ----------------------------------------  ---------------  -------------------------------------  -------------------------------
TensorFlow     v2.17.0                                   Apache-2.0       libtensorflowlite_c.so,                tensorflow/LICENSE
                                                                          libtensorflow-lite.so
Abseil         fb3621f4f897824c0dbe0615fa94543df6192f30  Apache-2.0       libabsl_*.so                           abseil-cpp/LICENSE
Eigen          c1d637433e3b3f9012b226c2c9125c494b470ae6  MPL-2.0          libtensorflow-lite.so (header-only)    eigen/COPYING.MPL2, COPYING.README
ruy            3286a34cc8de6149ac6844107dfdffac91531e72  Apache-2.0       libtensorflow-lite.so                  ruy/LICENSE
gemmlowp       16e8662c34917be0065110bfcd9cc27d30f52fdf  Apache-2.0       libtensorflow-lite.so                  gemmlowp/LICENSE
flatbuffers    e6463926479bd6b330cbcf673f7e917803fd5831  Apache-2.0       libtensorflow-lite.so                  flatbuffers/LICENSE
ml_dtypes      24084d9ed2c3d45bf83b7a9bff833aa185bf9172  Apache-2.0       libtensorflow-lite.so (header-only)    ml_dtypes/LICENSE
farmhash       0d859a811870d10f53a594927d0d0b97573ad06d  MIT              libfarmhash.so                         farmhash/COPYING
fft2d (Ooura)  OouraFFT v1.0, TensorFlow's mirror        Ooura's licence  libfft2d_fftsg.so,                     fft2d/readme.txt, readme2d.txt
                                                                          libfft2d_fftsg2d.so
cpuinfo        ef634603954d88d2643d5809011288b890ac126e  BSD-2-Clause     libcpuinfo.so                          cpuinfo/LICENSE
pthreadpool    4fe0e1e183925bf8cfa6aae24237e724a96479b8  BSD-2-Clause     libpthreadpool.so                      pthreadpool/LICENSE
FXdiv          master at build time (2026-08-23)         MIT              libpthreadpool.so (header-only)        FXdiv/LICENSE

Not included, although TensorFlow Lite can use them:
- XNNPACK: the build sets TFLITE_ENABLE_XNNPACK=OFF, and the libraries carry
  no xnn_* code. The only "XNNPACK" strings in libtensorflow-lite.so are
  TensorFlow's own delegate-settings names.
- FP16, NEON_2_SSE, OpenCL/Vulkan/GL headers: only used by XNNPACK, x86, the
  GPU delegate or NNAPI, none of which this build enables.
- protobuf: the configure step downloads it, but nothing built links it.

Eigen is under the MPL-2.0. Its source, unmodified, is at
  https://gitlab.com/libeigen/eigen/-/tree/c1d637433e3b3f9012b226c2c9125c494b470ae6
TensorFlow Lite defines EIGEN_MPL2_ONLY, so none of Eigen's LGPL-licensed code
is compiled in.

The libraries link dynamically against the system's musl, libstdc++ and
libgcc. Those come from the distribution's own packages and are not shipped
here.

How it was built
----------------
All steps ran in a postmarketOS/Alpine aarch64 build chroot (pmbootstrap, under
qemu), with the chroot's GCC (Alpine 15.2.0), on 2026-08-23:

  apk add cmake g++ make git python3 patch linux-headers
  wget https://github.com/tensorflow/tensorflow/archive/refs/tags/v2.17.0.tar.gz
  cmake tensorflow-2.17.0/tensorflow/lite/c -DCMAKE_BUILD_TYPE=Release \
        -DTFLITE_ENABLE_XNNPACK=OFF -DTFLITE_ENABLE_RUY=ON \
        -DTFLITE_ENABLE_GPU=OFF -DBUILD_SHARED_LIBS=ON
  make tensorflowlite_c

The first build stopped in flatbuffers/include/flatbuffers/util.h because musl
has no strtoll_l or strtoull_l. flatbuffers uses those locale-independent
calls whenever _XOPEN_VERSION >= 700, and musl sets that. The header was
edited in the build tree to get past this, and the build was then resumed.
The exact edit was not recorded. The upstream switch for this is to define
FLATBUFFERS_LOCALE_INDEPENDENT=0, for example with
-DCMAKE_CXX_FLAGS=-DFLATBUFFERS_LOCALE_INDEPENDENT=0.

The OouraFFT v1.0 archive that TensorFlow fetches is
  https://storage.googleapis.com/mirror.tensorflow.org/github.com/petewarden/OouraFFT/archive/v1.0.tar.gz
  sha256 5f4dabc2ae21e1f537425d58a49cdca1c49ea11db0d6271e2a4b27e9697548eb

The tarball holds the .so files from that build tree, plus this directory.
The licence texts were taken from each component's repository at the commit
listed above.
