/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Kernel API compatibility for the MT6625L WLAN driver.
 *
 * The vendor driver targets Linux 3.18; this tree is 7.0. Where the change is
 * a pure rename or an added argument with an obvious value, it is absorbed
 * here rather than by editing 169,000 lines of vendor source. That keeps the
 * driver diffable against the original, which matters if it ever has to be
 * re-synced.
 *
 * Anything that changed *semantically* is deliberately NOT handled here - it
 * is fixed at the call site, where the reader can see what happened. This file
 * is only for changes where the old and new spellings mean the same thing.
 *
 * Pulled into every translation unit with -include from the Makefile, so it
 * must include the real headers before redefining anything in them.
 */
#ifndef _MTK_COMPAT_H
#define _MTK_COMPAT_H

#include <linux/version.h>
#include <linux/netdevice.h>
#include <linux/sched/clock.h>	/* sched_clock(), split out of sched.h in 4.11 */
#include <linux/string.h>
#include <linux/timekeeping.h>
#include <net/netlink.h>
#include <net/cfg80211.h>

/*
 * The per-field flags in struct station_info were replaced in 4.0 (319090bf6c00)
 * by a bitmap indexed with the nl80211 enum, so `filled` is now built from
 * BIT_ULL(NL80211_STA_INFO_*) rather than from its own STATION_INFO_* set. The
 * names map one to one.
 */
#ifndef STATION_INFO_INACTIVE_TIME
#define STATION_INFO_INACTIVE_TIME	BIT_ULL(NL80211_STA_INFO_INACTIVE_TIME)
#define STATION_INFO_SIGNAL		BIT_ULL(NL80211_STA_INFO_SIGNAL)
#define STATION_INFO_TX_BITRATE		BIT_ULL(NL80211_STA_INFO_TX_BITRATE)
#define STATION_INFO_TX_PACKETS		BIT_ULL(NL80211_STA_INFO_TX_PACKETS)
#define STATION_INFO_TX_FAILED		BIT_ULL(NL80211_STA_INFO_TX_FAILED)
/*
 * There is deliberately no bit for the association request IEs: they never
 * moved into the bitmap. cfg80211 reads sinfo->assoc_req_ies together with
 * assoc_req_ies_len, so the flag has nothing to say and zero is correct.
 */
#define STATION_INFO_ASSOC_REQ_IES	0
#endif

/*
 * MODULE_SUPPORTED_DEVICE() was removed in 5.12 (b8660de5aa8b). It had never
 * done anything - it did not even emit a modinfo tag - so a no-op is a
 * faithful replacement.
 */
#ifndef MODULE_SUPPORTED_DEVICE
#define MODULE_SUPPORTED_DEVICE(x)
#endif

/* del_timer_sync() was renamed timer_delete_sync() in 6.2 (9b13df3fb64e). */
#ifndef del_timer_sync
#define del_timer_sync(t)	timer_delete_sync(t)
#endif

/* strnicmp was renamed to the standard spelling in 4.0 (0f7db81e0d64). */
#ifndef strnicmp
#define strnicmp(a, b, n)	strncasecmp(a, b, n)
#endif

/*
 * Bands were renamed from the ieee80211_ to the nl80211_ namespace in 4.7
 * (commit 57fbcce37b7d). Same values, same meaning.
 */
#ifndef IEEE80211_BAND_2GHZ
#define IEEE80211_BAND_2GHZ	NL80211_BAND_2GHZ
#endif
#ifndef IEEE80211_BAND_5GHZ
#define IEEE80211_BAND_5GHZ	NL80211_BAND_5GHZ
#endif
#ifndef IEEE80211_NUM_BANDS
#define IEEE80211_NUM_BANDS	NUM_NL80211_BANDS
#endif

/*
 * nla_parse_nested() gained a netlink_ext_ack argument in 4.12 (fceb6435e852).
 * The driver has no extack to report through, so pass NULL.
 *
 * The wrapper is defined before the macro on purpose: the macro takes four
 * arguments, so it cannot match the five-argument call inside the wrapper.
 */
static inline int mtk_compat_nla_parse_nested(struct nlattr *tb[], int maxtype,
					      const struct nlattr *nla,
					      const struct nla_policy *policy)
{
	return nla_parse_nested(tb, maxtype, nla, policy, NULL);
}
#define nla_parse_nested(tb, maxtype, nla, policy) \
	mtk_compat_nla_parse_nested(tb, maxtype, nla, policy)

/*
 * cfg80211_vendor_event_alloc() gained a wireless_dev argument in 4.4
 * (6c09e79178f1). It is allowed to be NULL, which is what the driver's
 * wiphy-scoped events want anyway.
 */
static inline struct sk_buff *
mtk_compat_vendor_event_alloc(struct wiphy *wiphy, int approxlen,
			      int event_idx, gfp_t gfp)
{
	return cfg80211_vendor_event_alloc(wiphy, NULL, approxlen,
					   event_idx, gfp);
}
#define cfg80211_vendor_event_alloc(wiphy, approxlen, event_idx, gfp) \
	mtk_compat_vendor_event_alloc(wiphy, approxlen, event_idx, gfp)

/*
 * The scheduled-scan notifications gained a request id in 4.12 (b34939b98369
 * and ca986ad9bcd5), when cfg80211 grew support for more than one concurrent
 * sched scan. This driver keeps exactly one - see max_sched_scan_reqs = 1 in
 * gl_init.c - so its id is always 0.
 */
static inline void mtk_compat_sched_scan_results(struct wiphy *wiphy)
{
	cfg80211_sched_scan_results(wiphy, 0);
}
#define cfg80211_sched_scan_results(wiphy) \
	mtk_compat_sched_scan_results(wiphy)

static inline void mtk_compat_sched_scan_stopped(struct wiphy *wiphy)
{
	cfg80211_sched_scan_stopped(wiphy, 0);
}
#define cfg80211_sched_scan_stopped(wiphy) \
	mtk_compat_sched_scan_stopped(wiphy)

/*
 * cfg80211_scan_done() took a bare `bool aborted` until 4.8 (1d76250bd202),
 * when it was boxed into cfg80211_scan_info so drivers could also report scan
 * start TSF and the responding BSSID. The driver has neither, and zeroing the
 * struct is the documented way to say so.
 */
static inline void mtk_compat_scan_done(struct cfg80211_scan_request *request,
					bool aborted)
{
	struct cfg80211_scan_info info = { .aborted = aborted };

	cfg80211_scan_done(request, &info);
}
#define cfg80211_scan_done(request, aborted) \
	mtk_compat_scan_done(request, aborted)

/*
 * cfg80211_ch_switch_notify() gained a link id in 6.0 with MLO. Single-link
 * driver, so link 0.
 */
static inline void mtk_compat_ch_switch_notify(struct net_device *dev,
					       struct cfg80211_chan_def *chandef)
{
	cfg80211_ch_switch_notify(dev, chandef, 0);
}
#define cfg80211_ch_switch_notify(dev, chandef) \
	mtk_compat_ch_switch_notify(dev, chandef)

/*
 * cfg80211_disconnected() gained `locally_generated` in 3.11 (80279fb7e5ec).
 * The only caller reports a deauth reason that came up from the firmware, i.e.
 * not one we generated locally, so false is both correct and what the old
 * four-argument form implied to userspace.
 */
static inline void mtk_compat_disconnected(struct net_device *dev, u16 reason,
					   const u8 *ie, size_t ie_len,
					   gfp_t gfp)
{
	cfg80211_disconnected(dev, reason, ie, ie_len, false, gfp);
}
#define cfg80211_disconnected(dev, reason, ie, ie_len, gfp) \
	mtk_compat_disconnected(dev, reason, ie, ie_len, gfp)

/*
 * netif_rx_ni() was folded into netif_rx() in 5.18 (baebdf48c3600), which now
 * works from any context.
 */
#ifndef netif_rx_ni
#define netif_rx_ni(skb)	netif_rx(skb)
#endif

#endif /* _MTK_COMPAT_H */

