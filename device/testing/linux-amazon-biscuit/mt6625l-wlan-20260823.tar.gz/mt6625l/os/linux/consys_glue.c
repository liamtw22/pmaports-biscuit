// SPDX-License-Identifier: GPL-2.0
/*
 * The one place this driver has to meet our CONSYS support.
 *
 * The vendor WLAN driver expects MediaTek's connectivity core (the mtk_wcn_*
 * stack). This port does not have it: CONSYS here is mt8163-consys.c, written
 * for this device and already proven by the Bluetooth path. Almost all of the
 * vendor integration points were resolved by selecting the driver's own
 * MTK_WCN_SINGLE_MODULE=1 configuration, which exists precisely for "no WMT
 * module" - see 11.78. This is the one that carries real behaviour.
 *
 * mtk_wcn_consys_hw_wifi_paldo_ctrl() switches the WLAN power amplifier LDO
 * between hardware and software control. In the vendor tree it is not a
 * separate rail at all:
 *
 *	INT32 mtk_wcn_consys_hw_wifi_paldo_ctrl(UINT32 enable)
 *	{
 *		mtk_wcn_consys_hw_bt_paldo_ctrl(enable);
 *		return 0;
 *	}
 *
 * It is literally the Bluetooth PALDO call, which is why the r192 notes record
 * that the BT and WIFI PALDO paths land on the same refcounted supply. Our
 * equivalent is mt8163_consys_bt_paldo_set(), driving MT8163_CONSYS_VCN33_BT -
 * the same rail.
 *
 * The consys device is found through the "mediatek,consys" phandle on our
 * wifi node, the same way the Bluetooth node references it.
 */
#include <linux/device.h>
#include <linux/of.h>
#include <linux/of_platform.h>
#include <linux/platform_device.h>

int mt8163_consys_bt_paldo_set(struct device *dev, bool on);

static struct device *mtk_wifi_consys_dev(void)
{
	struct device_node *wifi_np, *consys_np;
	struct platform_device *pdev;

	wifi_np = of_find_compatible_node(NULL, NULL, "mediatek,wifi");
	if (!wifi_np)
		return NULL;

	consys_np = of_parse_phandle(wifi_np, "mediatek,consys", 0);
	of_node_put(wifi_np);
	if (!consys_np)
		return NULL;

	pdev = of_find_device_by_node(consys_np);
	of_node_put(consys_np);
	if (!pdev)
		return NULL;

	/*
	 * Deliberately not put: the reference is held for the lifetime of the
	 * module, which is the lifetime of the power control it guards.
	 */
	return &pdev->dev;
}

int mtk_wcn_consys_hw_wifi_paldo_ctrl(unsigned int enable)
{
	struct device *consys = mtk_wifi_consys_dev();
	int ret;

	if (!consys) {
		pr_err("mt6625l: no mediatek,consys phandle; cannot set WLAN PALDO\n");
		return -ENODEV;
	}

	ret = mt8163_consys_bt_paldo_set(consys, !!enable);
	if (ret)
		pr_err("mt6625l: WLAN PALDO %s failed: %d\n",
		       enable ? "on" : "off", ret);

	return ret;
}

